<?xml version="1.0" encoding="ISO-8859-1"?>
<!--Edificios de la D.G. del Catastro.-->
<gml:FeatureCollection gml:id="ES.SDGC.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00100031_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336237.32 4559189.78</gml:lowerCorner>
         <gml:upperCorner>336245.9 4559200.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00100031_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00100031&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00100031&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00100031_PI.1" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336241.99 4559200.78 336245.9 4559191.82 336241.23 4559189.78 336237.32 4559198.74 336241.99 4559200.78</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00100033_PI.2">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336227.98 4559227.84</gml:lowerCorner>
         <gml:upperCorner>336236.5 4559232.9</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00100033_PI.2</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00100033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00100033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00100033_PI.2" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="47"> 336227.98 4559230.09 336228.02 4559230.52 336228.07 4559230.73 336228.33 4559231.32 336228.75 4559231.81 336229.29 4559232.16 336229.91 4559232.35 336230.34 4559232.37 336230.77 4559232.31 336231.37 4559232.08 336231.72 4559231.83 336231.92 4559231.64 336232.33 4559231.51 336232.74 4559231.49 336233.15 4559231.6 336233.51 4559231.81 336233.79 4559232.11 336234 4559232.46 336234.16 4559232.66 336234.38 4559232.81 336234.71 4559232.9 336234.96 4559232.88 336235.13 4559232.83 336235.35 4559232.7 336235.52 4559232.51 336235.66 4559232.19 336235.67 4559231.85 336235.73 4559231.64 336236.09 4559231.33 336236.28 4559231.07 336236.41 4559230.78 336236.5 4559230.32 336236.46 4559229.84 336236.35 4559229.54 336236.2 4559229.27 336235.87 4559228.92 336235.46 4559228.68 336235.31 4559228.63 336230.42 4559227.84 336229.94 4559227.86 336229.52 4559227.96 336229.13 4559228.13 336228.77 4559228.38 336228.48 4559228.69 336228.24 4559229.05 336228.02 4559229.66 336227.98 4559230.09</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00100051_PI.3">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336426.61 4559775.59</gml:lowerCorner>
         <gml:upperCorner>336434.86 4559787.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00100051_PI.3</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00100051&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00100051&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00100051_PI.3" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336434.22 4559779.18 336434.86 4559777.23 336429.87 4559775.59 336426.61 4559785.56 336431.6 4559787.19 336431.89 4559786.29 336434.22 4559779.18</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00200054_PI.4">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336840.1825 4559760.9985</gml:lowerCorner>
         <gml:upperCorner>336845.5125 4559769.3185</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00200054_PI.4</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00200054&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00200054&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00200054_PI.4" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="41"> 336841.5125 4559769.2385 336842.0125 4559769.3185 336842.3425 4559769.2985 336842.5625 4559769.2485 336842.8125 4559769.1085 336842.8925 4559769.0285 336843.0325 4559768.7985 336843.0925 4559768.6285 336843.1625 4559767.8985 336843.2025 4559766.7485 336843.3125 4559766.4085 336843.7125 4559765.9185 336844.4825 4559765.1685 336844.9325 4559764.6785 336845.0825 4559764.4785 336845.3625 4559763.8585 336845.4625 4559763.4585 336845.5125 4559763.0585 336845.4625 4559762.6985 336845.3525 4559762.3785 336845.1925 4559762.0685 336844.8025 4559761.4985 336844.5925 4559761.2785 336844.3925 4559761.1285 336844.2025 4559761.0485 336843.8625 4559760.9985 336843.7125 4559761.0285 336843.5625 4559761.1085 336843.2325 4559761.4385 336842.8525 4559761.9785 336841.5625 4559763.9985 336840.7025 4559765.4685 336840.3225 4559766.2585 336840.2225 4559766.5885 336840.1825 4559767.1585 336840.2625 4559767.6685 336840.3525 4559767.9085 336840.5625 4559768.3585 336840.8125 4559768.7585 336841.0525 4559768.9685 336841.5125 4559769.2385</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00200060_PI.5">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337057.9815 4559564.5365</gml:lowerCorner>
         <gml:upperCorner>337066.621 4559577.1065</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00200060_PI.5</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00200060&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00200060&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00200060_PI.5" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337061.6215 4559577.1065 337066.621 4559566.2065 337062.981 4559564.5365 337057.9815 4559575.4465 337061.6215 4559577.1065</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00300015_PI.6">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337666.9795 4557890.529</gml:lowerCorner>
         <gml:upperCorner>337673.6795 4557899.619</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-04-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00300015_PI.6</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00300015&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00300015&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00300015_PI.6" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337669.8395 4557890.529 337666.9795 4557898.169 337670.7495 4557899.619 337673.6795 4557892.009 337669.8395 4557890.529</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00300017_PI.7">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337572.918 4557697.0395</gml:lowerCorner>
         <gml:upperCorner>337578.598 4557703.9995</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00300017_PI.7</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00300017&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00300017&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00300017_PI.7" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337574.808 4557697.0395 337572.918 4557702.7395 337576.708 4557703.9995 337578.598 4557698.3095 337574.808 4557697.0395</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00300021_PI.8">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337335.2745 4557329.191</gml:lowerCorner>
         <gml:upperCorner>337347.6145 4557340.711</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00300021_PI.8</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00300021&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00300021&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00300021_PI.8" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 337335.2745 4557337.341 337343.8745 4557340.711 337347.6145 4557331.1605 337342.5845 4557329.191 337339.7345 4557336.381 337336.1945 4557334.991 337335.2745 4557337.341</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00300076_PI.9">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337059.696 4557588.2635</gml:lowerCorner>
         <gml:upperCorner>337063.766 4557594.3735</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00300076_PI.9</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00300076&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00300076&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00300076_PI.9" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337059.696 4557594.0635 337062.996 4557594.3735 337063.766 4557588.7135 337060.486 4557588.2635 337059.696 4557594.0635</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00300079_PI.10">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337046.737 4557673.4535</gml:lowerCorner>
         <gml:upperCorner>337056.487 4557679.6835</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00300079_PI.10</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00300079&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00300079&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00300079_PI.10" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337056.487 4557675.0935 337047.587 4557673.4535 337046.737 4557678.0535 337055.647 4557679.6835 337056.487 4557675.0935</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00400007_PI.11">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338390.8055 4557197.6325</gml:lowerCorner>
         <gml:upperCorner>338398.8655 4557204.5925</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00400007_PI.11</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00400007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00400007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00400007_PI.11" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338398.8655 4557201.1225 338392.7955 4557197.6325 338390.8055 4557201.1025 338396.8755 4557204.5925 338398.8655 4557201.1225</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00400012_PI.12">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337958.5335 4557051.8755</gml:lowerCorner>
         <gml:upperCorner>337969.7135 4557060.7155</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00400012_PI.12</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00400012&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00400012&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00400012_PI.12" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337960.7035 4557051.8755 337958.5335 4557056.3855 337967.5535 4557060.7155 337969.7135 4557056.2055 337960.7035 4557051.8755</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00400018_PI.13">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337488.4845 4557120.715</gml:lowerCorner>
         <gml:upperCorner>337509.5475 4557133.4215</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00400018_PI.13</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00400018&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00400018&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00400018_PI.13" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337509.5475 4557125.1615 337490.403 4557120.715 337488.4845 4557128.975 337507.629 4557133.4215 337509.5475 4557125.1615</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00400023_PI.14">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337716.2455 4557386.348</gml:lowerCorner>
         <gml:upperCorner>337727.7055 4557393.958</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00400023_PI.14</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00400023&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00400023&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00400023_PI.14" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 337716.2455 4557388.168 337716.2655 4557389.568 337717.0955 4557390.808 337718.4155 4557391.098 337719.4855 4557391.388 337721.4255 4557391.348 337722.1155 4557391.968 337722.9455 4557393.088 337726.6555 4557393.958 337727.7055 4557392.478 337727.2455 4557390.398 337725.8555 4557389.418 337723.9555 4557388.188 337721.2555 4557387.048 337718.6155 4557386.348 337717.4355 4557387.068 337716.2455 4557388.168</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00400048_PI.15">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337968.583 4556960.7955</gml:lowerCorner>
         <gml:upperCorner>337978.413 4556967.6755</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00400048_PI.15</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00400048&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00400048&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00400048_PI.15" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337969.973 4556960.7955 337968.583 4556964.5455 337977.023 4556967.6755 337978.413 4556963.9255 337969.973 4556960.7955</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500009_PI.16">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338557.8635 4556943.071</gml:lowerCorner>
         <gml:upperCorner>338565.1435 4556952.021</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500009_PI.16</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500009&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500009&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500009_PI.16" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338561.4035 4556952.021 338565.1435 4556944.941 338561.6035 4556943.071 338557.8635 4556950.151 338561.4035 4556952.021</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500011_PI.17">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338791.963 4556814.039</gml:lowerCorner>
         <gml:upperCorner>338807.583 4556830.009</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-07-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500011_PI.17</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500011&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500011&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500011_PI.17" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338791.963 4556819.479 338801.453 4556830.009 338807.583 4556825.039 338797.753 4556814.039 338791.963 4556819.479</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500013_PI.18">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338708.9 4556681.63</gml:lowerCorner>
         <gml:upperCorner>338720.59 4556691.22</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500013_PI.18</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500013&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500013&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500013_PI.18" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 338720.59 4556686.45 338712.09 4556681.63 338711.67 4556682.36 338711.12 4556682.2 338710.77 4556682.17 338710.24 4556682.24 338709.76 4556682.46 338709.48 4556682.68 338709.25 4556682.94 338709.07 4556683.25 338708.95 4556683.58 338708.9 4556684.11 338708.91 4556684.29 338708.99 4556684.63 338709.23 4556685.1 338709.79 4556685.69 338709.39 4556686.39 338717.89 4556691.22 338720.59 4556686.45</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500048_PI.19">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338219.4395 4556461.3325</gml:lowerCorner>
         <gml:upperCorner>338228.5995 4556467.5925</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500048_PI.19</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500048&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500048&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500048_PI.19" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="46"> 338219.5495 4556463.193 338219.4395 4556463.953 338219.5195 4556464.713 338219.5895 4556464.953 338219.7795 4556465.363 338220.2095 4556465.913 338220.8295 4556466.353 338221.3695 4556466.523 338221.9995 4556466.523 338222.5995 4556466.323 338222.9995 4556466.043 338223.4395 4556465.6325 338223.8795 4556465.4325 338224.5695 4556465.3625 338225.1395 4556465.5125 338225.6595 4556465.8825 338226.0395 4556466.3925 338226.2495 4556466.9925 338226.2595 4556467.5925 338226.8595 4556467.5925 338227.4195 4556467.4025 338227.8895 4556467.0325 338228.2095 4556466.5225 338228.4995 4556465.4725 338228.5995 4556464.3825 338228.4895 4556463.2925 338228.3595 4556462.6625 338228.0395 4556462.1025 338227.5595 4556461.6725 338226.9795 4556461.4025 338226.3395 4556461.3325 338225.9495 4556461.3825 338225.3395 4556461.5325 338224.3995 4556461.9225 338223.7795 4556462.3125 338223.4395 4556462.6625 338222.9495 4556462.8425 338222.5195 4556462.8125 338222.0895 4556462.593 338221.5295 4556461.883 338221.1495 4556461.683 338220.7195 4556461.683 338220.3295 4556461.883 338220.2095 4556462.003 338219.8595 4556462.483 338219.5495 4556463.193</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500054_PI.20">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337790.39 4556615.876</gml:lowerCorner>
         <gml:upperCorner>337798.97 4556621.106</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500054_PI.20</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500054&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500054&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500054_PI.20" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11"> 337790.39 4556617.4465 337790.4 4556618.0465 337790.61 4556618.6165 337790.93 4556619.0265 337798 4556621.106 337798.97 4556618.186 337792.02 4556615.876 337791.44 4556616.036 337790.93 4556616.3865 337790.57 4556616.8665 337790.39 4556617.4465</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500081_PI.21">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338285.64 4556513.09</gml:lowerCorner>
         <gml:upperCorner>338291.75 4556522.03</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-11-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500081_PI.21</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500081&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500081&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500081_PI.21" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 338287.45 4556522.03 338291.75 4556514.92 338288.72 4556513.09 338285.64 4556518.2 338287.88 4556519.55 338286.67 4556521.56 338287.45 4556522.03</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500091_PI.22">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337742.28 4556757.15</gml:lowerCorner>
         <gml:upperCorner>337746.89 4556762.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500091_PI.22</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500091&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500091&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500091_PI.22" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337742.28 4556761.38 337745.07 4556762.58 337746.89 4556758.34 337744.11 4556757.15 337742.28 4556761.38</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500103_PI.23">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337724.06 4556632.777</gml:lowerCorner>
         <gml:upperCorner>337731.55 4556637.7865</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500103_PI.23</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500103&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500103&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500103_PI.23" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337724.06 4556635.577 337729.9 4556637.7865 337731.55 4556635.0465 337724.5 4556632.777 337724.06 4556635.577</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00500112_PI.24">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337724.25 4556665.797</gml:lowerCorner>
         <gml:upperCorner>337732.53 4556672.097</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2008-04-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00500112_PI.24</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00500112&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00500112&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00500112_PI.24" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337725.64 4556665.797 337724.25 4556669.557 337731.14 4556672.097 337732.53 4556668.347 337725.64 4556665.797</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00600045_PI.25">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338891.4585 4556172.357</gml:lowerCorner>
         <gml:upperCorner>338905.7685 4556182.257</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-09T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00600045_PI.25</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00600045&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00600045&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00600045_PI.25" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338893.2785 4556182.257 338905.7685 4556178.627 338903.9485 4556172.357 338891.4585 4556175.987 338893.2785 4556182.257</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00700015_PI.26">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338895.0065 4555907.167</gml:lowerCorner>
         <gml:upperCorner>338905.2865 4555916.147</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2012-03-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00700015_PI.26</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00700015&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00700015&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00700015_PI.26" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338897.626 4555907.167 338895.0065 4555911.427 338902.6665 4555916.147 338905.2865 4555911.8865 338897.626 4555907.167</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00700017_PI.27">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338993.658 4556086.333</gml:lowerCorner>
         <gml:upperCorner>339003.22 4556093.979</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00700017_PI.27</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00700017&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00700017&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00700017_PI.27" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 339003.22 4556090.442 338995.9505 4556086.333 338995.545 4556087.051 338995.131 4556086.9045 338994.6915 4556086.9085 338994.479 4556086.9675 338994.1005 4556087.191 338993.8215 4556087.53 338993.73 4556087.7305 338993.658 4556088.164 338993.738 4556088.5955 338993.961 4556088.974 338994.3005 4556089.2535 338993.9515 4556089.8705 339001.2205 4556093.979 339003.22 4556090.442</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00700030_PI.28">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339236.16 4556380.06</gml:lowerCorner>
         <gml:upperCorner>339244.84 4556389.05</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00700030_PI.28</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00700030&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00700030&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00700030_PI.28" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339240.59 4556389.05 339244.84 4556383.4 339240.4 4556380.06 339236.16 4556385.71 339240.59 4556389.05</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00700032_PI.29">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339187.1585 4556317.7535</gml:lowerCorner>
         <gml:upperCorner>339194.54 4556324.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-05-31T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00700032_PI.29</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00700032&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00700032&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00700032_PI.29" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 339190.2935 4556317.7535 339190.07 4556317.975 339189.86 4556318.175 339187.1585 4556320.638 339191.74 4556324.75 339194.54 4556321.57 339190.2935 4556317.7535</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00700033_PI.30">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339222.62 4556343.98</gml:lowerCorner>
         <gml:upperCorner>339230.73 4556351.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-05-31T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00700033_PI.30</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00700033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00700033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00700033_PI.30" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339228.09 4556351.74 339230.73 4556348.65 339225.25 4556343.98 339222.62 4556347.07 339228.09 4556351.74</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00800010_PI.31">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339191.225 4555702.734</gml:lowerCorner>
         <gml:upperCorner>339201.695 4555713.694</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2008-03-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00800010_PI.31</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00800010&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00800010&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00800010_PI.31" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339193.715 4555702.734 339191.225 4555711.3945 339199.2055 4555713.694 339201.695 4555705.034 339193.715 4555702.734</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00800016_PI.32">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339469.0165 4555806.0025</gml:lowerCorner>
         <gml:upperCorner>339480.6865 4555818.8925</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00800016_PI.32</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00800016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00800016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00800016_PI.32" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339474.5765 4555806.0025 339469.0165 4555815.2025 339475.1265 4555818.8925 339480.6865 4555809.692 339474.5765 4555806.0025</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00800036_PI.33">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339390.51 4555406</gml:lowerCorner>
         <gml:upperCorner>339395.63 4555411.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00800036_PI.33</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00800036&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00800036&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00800036_PI.33" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339392.46 4555406 339390.51 4555408 339393.67 4555411.1 339395.63 4555409.1 339392.46 4555406</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00800038_PI.34">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338916.4125 4555554.751</gml:lowerCorner>
         <gml:upperCorner>338926.277 4555562.641</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00800038_PI.34</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00800038&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00800038&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00800038_PI.34" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 338926.277 4555556.163 338923.106 4555554.751 338922.468 4555556.2195 338922.275 4555556.664 338918.381 4555554.9725 338916.4125 4555559.5605 338923.5035 4555562.641 338926.277 4555556.163</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900001_PI.35">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339188.27 4554663.59</gml:lowerCorner>
         <gml:upperCorner>339199.68 4554672.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900001_PI.35</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900001_PI.35" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 339199.27 4554671.54 339199.49 4554671.26 339199.63 4554670.93 339199.65 4554670.45 339199.6 4554670.22 339199.44 4554669.9 339199.28 4554669.71 339199.05 4554669.54 339199.68 4554668.34 339190.68 4554663.59 339188.27 4554668.16 339197.27 4554672.91 339197.87 4554671.76 339198.16 4554671.86 339198.52 4554671.88 339198.98 4554671.75 339199.27 4554671.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900013_PI.36">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339714.935 4554219.854</gml:lowerCorner>
         <gml:upperCorner>339738.364 4554236.7545</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900013_PI.36</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900013&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900013&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900013_PI.36" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 339720.498 4554220.692 339718.5365 4554219.854 339714.935 4554228.2835 339716.775 4554229.0695 339734.763 4554236.7545 339738.1505 4554228.8245 339738.364 4554228.325 339720.498 4554220.692</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900016_PI.37">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339948.822 4553802.0755</gml:lowerCorner>
         <gml:upperCorner>339960.062 4553813.4655</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900016_PI.37</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900016_PI.37" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339948.822 4553806.1855 339955.682 4553813.4655 339960.062 4553809.3555 339953.202 4553802.0755 339948.822 4553806.1855</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900020_PI.38">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339735.18 4553936.91</gml:lowerCorner>
         <gml:upperCorner>339746.43 4553948.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900020_PI.38</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900020_PI.38" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339735.18 4553944.53 339739.86 4553948.56 339746.43 4553940.94 339741.76 4553936.91 339735.18 4553944.53</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900022_PI.39">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339354.113 4554165.7405</gml:lowerCorner>
         <gml:upperCorner>339362.056 4554171.4395</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900022_PI.39</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900022&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900022&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900022_PI.39" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339360.9725 4554171.4395 339362.056 4554167.7965 339355.1405 4554165.7405 339354.113 4554169.1975 339360.9725 4554171.4395</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900027_PI.40">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339261.484 4554238.4515</gml:lowerCorner>
         <gml:upperCorner>339268.624 4554245.4415</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900027_PI.40</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900027&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900027&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900027_PI.40" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339268.624 4554240.6315 339266.564 4554238.4515 339261.484 4554243.2715 339263.554 4554245.4415 339268.624 4554240.6315</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900030_PI.41">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339447.1255 4554365.28</gml:lowerCorner>
         <gml:upperCorner>339457.0755 4554377.25</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-01-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900030_PI.41</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900030&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900030&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900030_PI.41" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 339451.8655 4554366.89 339447.1255 4554373.34 339452.4455 4554377.25 339453.0455 4554376.44 339451.7555 4554375.49 339457.0755 4554368.24 339453.0455 4554365.28 339451.8655 4554366.89</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900031_PI.42">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339436.41 4554321.71</gml:lowerCorner>
         <gml:upperCorner>339446.26 4554331.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900031_PI.42</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900031&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900031&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900031_PI.42" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 339446.26 4554325.68 339440.27 4554321.71 339436.41 4554327.53 339442.25 4554331.4 339444.39 4554328.17 339446.26 4554325.68</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900038_PI.43">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339540.67 4554165.53</gml:lowerCorner>
         <gml:upperCorner>339545.35 4554170.68</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900038_PI.43</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900038&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900038&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900038_PI.43" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339540.67 4554169.18 339543.09 4554170.68 339545.35 4554167.02 339542.94 4554165.53 339540.67 4554169.18</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900039_PI.44">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339524.374 4554173.1895</gml:lowerCorner>
         <gml:upperCorner>339528.564 4554177.6495</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900039_PI.44</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900039&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900039&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900039_PI.44" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339524.374 4554176.2995 339526.054 4554177.6495 339528.564 4554174.5395 339526.884 4554173.1895 339524.374 4554176.2995</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900041_PI.45">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339507.92 4554199.62</gml:lowerCorner>
         <gml:upperCorner>339516.25 4554208.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900041_PI.45</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900041&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900041&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900041_PI.45" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339512.02 4554208.36 339516.25 4554202.68 339512.15 4554199.62 339507.92 4554205.31 339512.02 4554208.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A00900046_PI.46">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339220.01 4554233.57</gml:lowerCorner>
         <gml:upperCorner>339229.82 4554241.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-03-05T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A00900046_PI.46</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A00900046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A00900046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A00900046_PI.46" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339221.93 4554233.57 339220.01 4554237.08 339227.9 4554241.41 339229.82 4554237.9 339221.93 4554233.57</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01000020_PI.47">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339535.37 4553580.018</gml:lowerCorner>
         <gml:upperCorner>339571.92 4553612.888</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01000020_PI.47</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01000020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01000020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01000020_PI.47" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339549.7095 4553580.018 339535.37 4553599.9485 339557.25 4553612.888 339571.92 4553592.558 339549.7095 4553580.018</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100001_PI.48">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339742.693 4552662.4555</gml:lowerCorner>
         <gml:upperCorner>339755.993 4552673.345</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100001_PI.48</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100001_PI.48" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339744.973 4552662.4555 339742.693 4552670.0255 339753.713 4552673.345 339755.993 4552665.775 339744.973 4552662.4555</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100005_PI.49">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339865.96 4552876.62</gml:lowerCorner>
         <gml:upperCorner>339872.98 4552882.62</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100005_PI.49</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100005&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100005&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100005_PI.49" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 339871.06 4552882.62 339872.98 4552879.29 339868.38 4552876.69 339867.96 4552876.62 339867.6 4552876.64 339867.24 4552876.73 339866.76 4552876.98 339866.48 4552877.22 339866.26 4552877.5 339866.03 4552878 339865.96 4552878.36 339865.96 4552878.72 339866.03 4552879.08 339866.16 4552879.42 339866.36 4552879.72 339866.52 4552879.9 339871.06 4552882.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100008_PI.50">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339983.79 4553213</gml:lowerCorner>
         <gml:upperCorner>339999.13 4553226.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100008_PI.50</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100008&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100008&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100008_PI.50" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339999.13 4553218.79 339995.33 4553213 339983.79 4553220.58 339987.59 4553226.36 339999.13 4553218.79</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100015_PI.51">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>340480.42 4553048.68</gml:lowerCorner>
         <gml:upperCorner>340490.01 4553060.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100015_PI.51</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100015&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100015&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100015_PI.51" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 340480.42 4553058.15 340484.59 4553060.54 340490.01 4553051.06 340485.83 4553048.68 340480.42 4553058.15</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100016_PI.52">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>340019.334 4552751.5135</gml:lowerCorner>
         <gml:upperCorner>340023.794 4552755.9335</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100016_PI.52</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100016_PI.52" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29"> 340023.794 4552753.4135 340023.494 4552753.0435 340023.164 4552752.7035 340022.814 4552752.4035 340022.024 4552751.8835 340021.594 4552751.6735 340021.154 4552751.5135 340020.724 4552751.7035 340020.324 4552751.9635 340019.984 4552752.2935 340019.844 4552752.4835 340019.594 4552752.8835 340019.504 4552753.1035 340019.374 4552753.5635 340019.334 4552754.0335 340019.634 4552754.4035 340019.964 4552754.7435 340020.704 4552755.3235 340021.104 4552755.5635 340021.534 4552755.7735 340021.974 4552755.9335 340022.194 4552755.8535 340022.614 4552755.6235 340022.974 4552755.3235 340023.294 4552754.9635 340023.424 4552754.7635 340023.624 4552754.3435 340023.754 4552753.8835 340023.794 4552753.4135</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100019_PI.53">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339872.91 4552603.34</gml:lowerCorner>
         <gml:upperCorner>339886 4552611.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100019_PI.53</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100019&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100019&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100019_PI.53" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339886 4552605.4 339874 4552603.34 339872.91 4552609.68 339884.91 4552611.74 339886 4552605.4</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100025_PI.54">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339544.412 4552552.6965</gml:lowerCorner>
         <gml:upperCorner>339551.412 4552561.7665</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100025_PI.54</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100025&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100025&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100025_PI.54" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339549.222 4552561.7665 339551.412 4552554.0665 339546.602 4552552.6965 339544.412 4552560.3965 339549.222 4552561.7665</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100037_PI.55">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339989.64 4552666.27</gml:lowerCorner>
         <gml:upperCorner>339995.8 4552673.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100037_PI.55</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100037&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100037&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100037_PI.55" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339989.64 4552671.94 339992.32 4552673.58 339995.8 4552667.91 339993.12 4552666.27 339989.64 4552671.94</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100038_PI.56">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>340004.2535 4552676.0535</gml:lowerCorner>
         <gml:upperCorner>340009.9635 4552682.7335</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100038_PI.56</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100038&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100038&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100038_PI.56" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 340007.4135 4552676.0535 340004.2535 4552681.1535 340006.8035 4552682.7335 340009.9635 4552677.6335 340007.4135 4552676.0535</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100041_PI.57">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339983.273 4552587.1635</gml:lowerCorner>
         <gml:upperCorner>339996.503 4552598.7635</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100041_PI.57</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100041&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100041&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100041_PI.57" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339983.273 4552593.0335 339993.073 4552598.7635 339996.503 4552592.9035 339986.713 4552587.1635 339983.273 4552593.0335</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100042_PI.58">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>340001.083 4552613.1135</gml:lowerCorner>
         <gml:upperCorner>340006.923 4552619.6135</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100042_PI.58</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100042&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100042&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100042_PI.58" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 340003.873 4552613.1135 340001.083 4552617.7335 340004.103 4552619.6135 340006.923 4552614.953 340003.873 4552613.1135</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01100045_PI.59">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339957.4685 4552574.0085</gml:lowerCorner>
         <gml:upperCorner>339964.0665 4552584.4335</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01100045_PI.59</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01100045&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01100045&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01100045_PI.59" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 339964.0665 4552575.108 339959.8715 4552574.0085 339957.4685 4552582.1695 339958.4635 4552582.55 339958.3575 4552582.827 339958.3305 4552583.336 339958.501 4552583.8165 339958.844 4552584.194 339959.305 4552584.411 339959.8145 4552584.4335 339960.153 4552584.333 339960.2935 4552584.2585 339960.668 4552583.913 339960.881 4552583.45 339960.8995 4552582.9405 339961.797 4552583.192 339964.0665 4552575.108</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200020_PI.60">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339247.358 4552093.718</gml:lowerCorner>
         <gml:upperCorner>339274.178 4552114.178</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200020_PI.60</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200020_PI.60" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="92"> 339273.178 4552110.518 339273.448 4552110.008 339273.848 4552108.928 339274.098 4552107.818 339274.168 4552107.268 339274.178 4552106.698 339274.128 4552106.108 339273.978 4552105.478 339273.758 4552104.828 339273.138 4552103.508 339272.768 4552102.858 339272.358 4552102.238 339271.928 4552101.668 339271.478 4552101.138 339270.568 4552100.258 339270.118 4552099.888 339269.658 4552099.568 339269.198 4552099.298 339268.738 4552099.058 339268.268 4552098.888 339267.808 4552098.778 339267.328 4552098.718 339266.818 4552098.698 339265.718 4552098.758 339265.148 4552098.838 339264.588 4552098.958 339263.528 4552099.248 339262.598 4552099.558 339260.638 4552100.328 339260.198 4552100.438 339259.698 4552100.478 339259.138 4552100.418 339258.548 4552100.268 339257.998 4552100.038 339257.518 4552099.758 339257.108 4552099.438 339256.778 4552099.088 339256.268 4552098.308 339255.368 4552096.458 339254.928 4552095.658 339254.698 4552095.298 339254.158 4552094.668 339253.868 4552094.388 339253.558 4552094.158 339253.218 4552093.958 339252.808 4552093.818 339252.318 4552093.728 339251.748 4552093.718 339251.078 4552093.808 339250.358 4552094.028 339249.708 4552094.318 339249.278 4552094.598 339248.438 4552095.408 339247.968 4552096.108 339247.718 4552096.738 339247.558 4552097.328 339247.448 4552097.888 339247.358 4552098.938 339247.388 4552099.948 339247.538 4552101.018 339247.808 4552102.078 339248.008 4552102.618 339248.278 4552103.178 339248.628 4552103.788 339249.028 4552104.408 339249.458 4552104.998 339250.288 4552106.028 339250.718 4552106.508 339251.668 4552107.468 339252.708 4552108.418 339253.788 4552109.308 339255.788 4552110.808 339256.978 4552111.598 339257.798 4552112.078 339259.608 4552112.998 339260.398 4552113.318 339261.098 4552113.548 339262.438 4552113.878 339263.108 4552114.018 339264.448 4552114.178 339265.788 4552114.178 339267.198 4552114.078 339267.918 4552113.968 339268.618 4552113.788 339269.298 4552113.558 339269.938 4552113.268 339270.538 4552112.938 339271.098 4552112.578 339272.068 4552111.828 339272.488 4552111.428 339272.858 4552110.998 339273.178 4552110.518</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200023_PI.61">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339312.6385 4552179.078</gml:lowerCorner>
         <gml:upperCorner>339324.0885 4552191.778</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200023_PI.61</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200023&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200023&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200023_PI.61" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339318.0285 4552179.078 339312.6385 4552188.188 339318.699 4552191.778 339324.0885 4552182.6675 339318.0285 4552179.078</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200033_PI.62">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339113.4355 4551819.4585</gml:lowerCorner>
         <gml:upperCorner>339122.3755 4551829.4985</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-07-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200033_PI.62</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200033_PI.62" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 339115.0955 4551823.859 339113.4355 4551826.769 339118.2055 4551829.4985 339122.3755 4551822.1885 339117.6055 4551819.4585 339116.2655 4551821.809 339115.0955 4551823.859</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200035_PI.63">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339541.181 4552419.3965</gml:lowerCorner>
         <gml:upperCorner>339552.801 4552431.2765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200035_PI.63</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200035&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200035&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200035_PI.63" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339552.801 4552422.7965 339544.781 4552419.3965 339541.181 4552427.8665 339549.201 4552431.2765 339552.801 4552422.7965</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200039_PI.64">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339475.07 4552289.477</gml:lowerCorner>
         <gml:upperCorner>339479.78 4552293.5265</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200039_PI.64</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200039&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200039&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200039_PI.64" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339478.89 4552293.5265 339479.78 4552290.6565 339475.9495 4552289.477 339475.07 4552292.347 339478.89 4552293.5265</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200045_PI.65">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339376.8695 4552276.0775</gml:lowerCorner>
         <gml:upperCorner>339388.3695 4552285.3775</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200045_PI.65</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200045&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200045&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200045_PI.65" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339376.8695 4552280.8175 339385.9995 4552285.3775 339388.3695 4552280.6375 339379.2395 4552276.0775 339376.8695 4552280.8175</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01200046_PI.66">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339215.2555 4552424.5565</gml:lowerCorner>
         <gml:upperCorner>339224.806 4552432.463</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01200046_PI.66</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01200046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01200046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01200046_PI.66" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22"> 339217.4515 4552432.3955 339218.448 4552432.463 339219.189 4552432.328 339220.1455 4552431.749 339220.8725 4552430.8465 339221.1825 4552430.0115 339221.546 4552428.705 339221.937 4552428.3685 339222.6105 4552428.3685 339223.944 4552428.867 339224.806 4552427.1025 339223.055 4552426.146 339222.772 4552425.6075 339221.856 4552424.8125 339220.8325 4552424.5565 339219.674 4552424.678 339218.273 4552425.5265 339216.36 4552427.1025 339215.404 4552428.328 339215.2555 4552429.6615 339215.498 4552430.7795 339217.4515 4552432.3955</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01300010_PI.67">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338564.73 4553112.16</gml:lowerCorner>
         <gml:upperCorner>338578.6345 4553123.095</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01300010_PI.67</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01300010&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01300010&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01300010_PI.67" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 338573.84 4553115.62 338567.31 4553112.16 338564.73 4553117.02 338576.1845 4553123.095 338578.6345 4553118.165 338573.84 4553115.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500028_PI.68">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337507.3005 4552758.4825</gml:lowerCorner>
         <gml:upperCorner>337518.59 4552771.4125</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500028_PI.68</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500028&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500028&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500028_PI.68" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337507.3005 4552768.3425 337514.2005 4552771.4125 337518.59 4552761.5625 337511.69 4552758.4825 337507.3005 4552768.3425</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500033_PI.69">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337482.94 4552900.04</gml:lowerCorner>
         <gml:upperCorner>337489.98 4552910.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500033_PI.69</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500033_PI.69" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 337485.93 4552900.04 337482.94 4552909.37 337486.99 4552910.66 337489.98 4552901.34 337489.74 4552901.26 337485.93 4552900.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500046_PI.70">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337952.03 4552658.049</gml:lowerCorner>
         <gml:upperCorner>337959.86 4552667.719</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500046_PI.70</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500046_PI.70" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337952.03 4552665.729 337956.1 4552667.719 337959.86 4552660.039 337955.8 4552658.049 337952.03 4552665.729</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500066_PI.71">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337493.639 4552576.762</gml:lowerCorner>
         <gml:upperCorner>337500.289 4552586.862</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500066_PI.71</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500066&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500066&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500066_PI.71" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 337493.829 4552576.762 337493.639 4552586.762 337498.639 4552586.862 337498.759 4552580.612 337499.179 4552580.562 337499.539 4552580.412 337499.849 4552580.172 337500.089 4552579.862 337500.239 4552579.502 337500.289 4552579.112 337500.239 4552578.722 337500.089 4552578.362 337499.849 4552578.052 337499.539 4552577.812 337499.179 4552577.662 337498.819 4552577.612 337498.829 4552576.862 337493.829 4552576.762</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500071_PI.72">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337701.009 4552683.506</gml:lowerCorner>
         <gml:upperCorner>337714.584 4552694.5765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500071_PI.72</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500071&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500071&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500071_PI.72" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 337708.7265 4552686.025 337703.8685 4552683.506 337701.009 4552689.02 337705.305 4552691.2475 337711.7245 4552694.5765 337714.584 4552689.062 337708.7265 4552686.025</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500079_PI.73">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337946.5175 4552302.9585</gml:lowerCorner>
         <gml:upperCorner>337955.3375 4552310.9185</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500079_PI.73</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500079&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500079&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500079_PI.73" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337948.8775 4552302.9585 337946.5175 4552306.1885 337952.9675 4552310.9185 337955.3375 4552307.6885 337948.8775 4552302.9585</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01500101_PI.74">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337578.2235 4551870.2005</gml:lowerCorner>
         <gml:upperCorner>337584.4935 4551876.7305</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01500101_PI.74</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01500101&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01500101&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01500101_PI.74" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 337583.8335 4551870.9905 337583.3235 4551870.5805 337582.7235 4551870.3005 337582.0635 4551870.2005 337581.4135 4551870.2705 337578.2235 4551874.1205 337578.2735 4551874.7805 337578.5035 4551875.4005 337578.8935 4551875.9405 337579.3935 4551876.3605 337579.9935 4551876.6305 337580.6535 4551876.7305 337581.3035 4551876.6705 337584.4935 4551872.8205 337584.4435 4551872.1505 337584.2135 4551871.5405 337583.8335 4551870.9905</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700001_PI.75">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336148.6245 4553580.554</gml:lowerCorner>
         <gml:upperCorner>336157.4445 4553588.514</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-07-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700001_PI.75</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700001_PI.75" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336157.4445 4553585.294 336150.9945 4553580.554 336148.6245 4553583.774 336155.0745 4553588.514 336157.4445 4553585.294</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700005_PI.76">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336360.986 4553722.6325</gml:lowerCorner>
         <gml:upperCorner>336369.0055 4553731.3325</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700005_PI.76</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700005&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700005&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700005_PI.76" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336369.0055 4553725.2325 336364.5055 4553722.6325 336360.986 4553728.7425 336365.486 4553731.3325 336369.0055 4553725.2325</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700012_PI.77">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336678.818 4553936.5405</gml:lowerCorner>
         <gml:upperCorner>336688.068 4553946.7205</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700012_PI.77</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700012&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700012&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700012_PI.77" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336681.918 4553946.7205 336688.068 4553939.0205 336684.968 4553936.5405 336678.818 4553944.2405 336681.918 4553946.7205</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700021_PI.78">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336696.51 4553510.94</gml:lowerCorner>
         <gml:upperCorner>336706.66 4553521.81</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700021_PI.78</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700021&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700021&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700021_PI.78" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336702.68 4553521.81 336706.66 4553515.51 336700.66 4553510.94 336696.51 4553516.4 336702.68 4553521.81</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700021_PI.79">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336736.3 4553479.64</gml:lowerCorner>
         <gml:upperCorner>336747.57 4553492.49</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700021_PI.79</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700021&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700021&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700021_PI.79" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336736.3 4553489.36 336740.81 4553492.49 336747.57 4553482.78 336743.07 4553479.64 336736.3 4553489.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700033_PI.80">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337286.44 4553206.68</gml:lowerCorner>
         <gml:upperCorner>337292.14 4553214.25</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700033_PI.80</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700033_PI.80" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="53"> 337287.56 4553214.12 337288 4553214.25 337288.41 4553214.25 337288.67 4553214.19 337288.92 4553214.07 337289.24 4553213.82 337289.47 4553213.49 337289.57 4553213.24 337289.62 4553212.97 337289.64 4553212.33 337289.69 4553212.13 337289.83 4553211.75 337290.04 4553211.4 337290.31 4553211.1 337290.47 4553210.97 337290.82 4553210.76 337291.25 4553210.61 337291.71 4553210.1 337291.92 4553209.75 337292.07 4553209.37 337292.14 4553208.77 337292.09 4553208.36 337291.97 4553207.97 337291.77 4553207.62 337291.51 4553207.3 337291.2 4553207.05 337290.84 4553206.85 337290.46 4553206.73 337290.05 4553206.68 337289.65 4553206.71 337289.25 4553206.81 337288.89 4553206.99 337288.56 4553207.23 337288.29 4553207.53 337288.08 4553207.88 337287.86 4553208.51 337287.89 4553209.14 337287.83 4553209.54 337287.76 4553209.73 337287.59 4553210.1 337287.47 4553210.27 337287.2 4553210.57 337287.05 4553210.69 337286.76 4553211.1 337286.58 4553211.47 337286.47 4553211.86 337286.45 4553212.06 337286.44 4553212.27 337286.49 4553212.67 337286.71 4553213.24 337286.93 4553213.58 337287.07 4553213.73 337287.56 4553214.12</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700052_PI.81">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336485.9 4553253.24</gml:lowerCorner>
         <gml:upperCorner>336493.04 4553261.45</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700052_PI.81</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700052&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700052&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700052_PI.81" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336493.04 4553255.3 336489.6 4553253.24 336485.9 4553259.38 336489.33 4553261.45 336493.04 4553255.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01700093_PI.82">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336325.0855 4553731.693</gml:lowerCorner>
         <gml:upperCorner>336332.286 4553738.183</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01700093_PI.82</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01700093&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01700093&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01700093_PI.82" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336332.286 4553734.733 336327.1055 4553731.693 336325.0855 4553735.143 336330.256 4553738.183 336332.286 4553734.733</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01800001_PI.83">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335608.12 4554124.73</gml:lowerCorner>
         <gml:upperCorner>335618.24 4554135.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01800001_PI.83</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01800001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01800001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01800001_PI.83" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 335610.51 4554135.61 335611.84 4554134.07 335612.54 4554134.68 335618.24 4554128.11 335614.35 4554124.73 335608.66 4554131.29 335609.46 4554131.99 335608.12 4554133.54 335610.51 4554135.61</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01800023_PI.84">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335734.41 4554106.25</gml:lowerCorner>
         <gml:upperCorner>335743.11 4554114.23</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-01-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01800023_PI.84</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01800023&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01800023&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01800023_PI.84" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335734.41 4554109.42 335740.67 4554114.23 335743.11 4554111.06 335736.84 4554106.25 335734.41 4554109.42</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01800040_PI.85">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335736.307 4554020.3575</gml:lowerCorner>
         <gml:upperCorner>335741.987 4554029.9475</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01800040_PI.85</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01800040&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01800040&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01800040_PI.85" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 335737.537 4554020.6275 335736.527 4554021.5975 335736.307 4554023.5775 335736.687 4554025.6075 335737.647 4554026.5675 335737.647 4554028.0175 335738.027 4554028.7675 335738.667 4554029.4075 335739.577 4554029.9475 335740.647 4554029.8875 335741.507 4554029.1975 335741.987 4554028.1275 335741.607 4554021.5375 335740.757 4554020.7375 335739.357 4554020.3575 335737.537 4554020.6275</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01800042_PI.86">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335842.617 4554000.797</gml:lowerCorner>
         <gml:upperCorner>335849.757 4554008.207</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01800042_PI.86</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01800042&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01800042&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01800042_PI.86" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335847.307 4554000.797 335842.617 4554005.997 335845.067 4554008.207 335849.757 4554003.007 335847.307 4554000.797</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01900001_PI.87">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335294.522 4554765.622</gml:lowerCorner>
         <gml:upperCorner>335307.062 4554779.642</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01900001_PI.87</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01900001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01900001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01900001_PI.87" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335294.522 4554776.202 335299.092 4554779.642 335307.062 4554769.072 335302.492 4554765.622 335294.522 4554776.202</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01900004_PI.88">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335459.98 4554882.01</gml:lowerCorner>
         <gml:upperCorner>335465.48 4554888.62</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01900004_PI.88</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01900004&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01900004&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01900004_PI.88" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335462.76 4554888.62 335465.48 4554883.49 335462.7 4554882.01 335459.98 4554887.14 335462.76 4554888.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01900007_PI.89">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335756.57 4555011.86</gml:lowerCorner>
         <gml:upperCorner>335769.69 4555022.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01900007_PI.89</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01900007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01900007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01900007_PI.89" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335758.89 4555011.86 335756.57 4555015.23 335767.37 4555022.66 335769.69 4555019.28 335758.89 4555011.86</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01900020_PI.90">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335577.9995 4554350.7995</gml:lowerCorner>
         <gml:upperCorner>335581.7795 4554356.2195</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01900020_PI.90</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01900020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01900020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01900020_PI.90" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335577.9995 4554355.7295 335580.9595 4554356.2195 335581.7795 4554351.2895 335578.819 4554350.7995 335577.9995 4554355.7295</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A01900021_PI.91">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335557.359 4554300.1695</gml:lowerCorner>
         <gml:upperCorner>335566.729 4554307.6495</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A01900021_PI.91</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A01900021&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A01900021&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A01900021_PI.91" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335566.729 4554300.6595 335557.739 4554300.1695 335557.359 4554307.1595 335566.349 4554307.6495 335566.729 4554300.6595</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02000028_PI.92">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335129.5745 4555123.6535</gml:lowerCorner>
         <gml:upperCorner>335139.2455 4555131.8685</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-12-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02000028_PI.92</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02000028&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02000028&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02000028_PI.92" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335129.5745 4555129.371 335137.427 4555131.8685 335139.2455 4555126.151 335131.3935 4555123.6535 335129.5745 4555129.371</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02000061_PI.93">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335261.4255 4555213.303</gml:lowerCorner>
         <gml:upperCorner>335272.1555 4555221.363</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02000061_PI.93</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02000061&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02000061&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02000061_PI.93" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335270.3655 4555221.363 335272.1555 4555217.793 335263.2155 4555213.303 335261.4255 4555216.883 335270.3655 4555221.363</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02000087_PI.94">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335570.008 4555526.0515</gml:lowerCorner>
         <gml:upperCorner>335577.508 4555534.0615</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02000087_PI.94</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02000087&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02000087&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02000087_PI.94" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335572.268 4555534.0615 335577.508 4555528.0215 335575.248 4555526.0515 335570.008 4555532.1015 335572.268 4555534.0615</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02000096_PI.95">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335689.4655 4555143.85</gml:lowerCorner>
         <gml:upperCorner>335698.8255 4555153.51</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02000096_PI.95</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02000096&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02000096&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02000096_PI.95" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335698.8255 4555149.97 335693.6755 4555143.85 335689.4655 4555147.39 335694.6155 4555153.51 335698.8255 4555149.97</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200003_PI.96">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335332.06 4555332.91</gml:lowerCorner>
         <gml:upperCorner>335342.87 4555343.96</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200003_PI.96</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200003&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200003&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200003_PI.96" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335342.87 4555336.3 335339.09 4555332.91 335332.06 4555340.57 335335.84 4555343.96 335342.87 4555336.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200012_PI.97">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334843.563 4555006.456</gml:lowerCorner>
         <gml:upperCorner>334852.213 4555013.176</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200012_PI.97</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200012&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200012&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200012_PI.97" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334850.633 4555013.176 334852.213 4555009.496 334845.143 4555006.456 334843.563 4555010.136 334850.633 4555013.176</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200013_PI.98">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334729.483 4554990.807</gml:lowerCorner>
         <gml:upperCorner>334734.913 4555000.817</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200013_PI.98</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200013&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200013&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200013_PI.98" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 334729.483 4555000.027 334733.413 4555000.817 334734.913 4554993.367 334733.933 4554993.167 334734.333 4554991.207 334732.373 4554990.807 334731.973 4554992.767 334730.993 4554992.577 334729.483 4555000.027</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200025_PI.99">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334571.025 4555326.8585</gml:lowerCorner>
         <gml:upperCorner>334578.795 4555334.7185</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200025_PI.99</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200025&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200025&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200025_PI.99" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334577.045 4555334.7185 334578.795 4555328.6085 334572.715 4555326.8585 334571.025 4555332.9885 334577.045 4555334.7185</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200027_PI.100">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334776.16 4555326.45</gml:lowerCorner>
         <gml:upperCorner>334785.99 4555332.04</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200027_PI.100</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200027&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200027&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200027_PI.100" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 334785.44 4555332.04 334785.99 4555328.25 334776.36 4555326.45 334776.16 4555327.53 334777.75 4555328.63 334777.39 4555330.53 334785.44 4555332.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200038_PI.101">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334804.554 4555117.9765</gml:lowerCorner>
         <gml:upperCorner>334809.144 4555123.8765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200038_PI.101</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200038&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200038&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200038_PI.101" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334805.164 4555117.9765 334804.554 4555123.4365 334808.534 4555123.8765 334809.144 4555118.4165 334805.164 4555117.9765</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200041_PI.102">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334683.003 4554987.857</gml:lowerCorner>
         <gml:upperCorner>334689.2025 4554996.227</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200041_PI.102</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200041&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200041&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200041_PI.102" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334685.0725 4554987.857 334683.003 4554995.037 334687.143 4554996.227 334689.2025 4554989.047 334685.0725 4554987.857</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02200044_PI.103">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334418.333 4555098.7895</gml:lowerCorner>
         <gml:upperCorner>334424.983 4555103.8495</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-21T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02200044_PI.103</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02200044&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02200044&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02200044_PI.103" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334424.223 4555103.8495 334424.983 4555099.9195 334419.083 4555098.7895 334418.333 4555102.7095 334424.223 4555103.8495</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300001_PI.104">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334499.6215 4556181.7705</gml:lowerCorner>
         <gml:upperCorner>334508.2115 4556191.0605</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300001_PI.104</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300001_PI.104" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334499.6215 4556188.3005 334503.2615 4556191.0605 334508.2115 4556184.5305 334504.5715 4556181.7705 334499.6215 4556188.3005</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300007_PI.105">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334870.589 4555882.656</gml:lowerCorner>
         <gml:upperCorner>334877.034 4555889.299</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300007_PI.105</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300007_PI.105" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334870.589 4555884.606 334874.531 4555889.299 334877.034 4555887.1965 334873.351 4555882.656 334870.589 4555884.606</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300021_PI.106">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335673.58 4555764.721</gml:lowerCorner>
         <gml:upperCorner>335681.54 4555773.571</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300021_PI.106</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300021&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300021&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300021_PI.106" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335681.54 4555766.901 335678.68 4555764.721 335673.58 4555771.391 335676.44 4555773.571 335681.54 4555766.901</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300033_PI.107">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335316.358 4555581.1935</gml:lowerCorner>
         <gml:upperCorner>335326.888 4555591.8735</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300033_PI.107</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300033_PI.107" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335326.888 4555584.6535 335323.268 4555581.1935 335316.358 4555588.4235 335319.9685 4555591.8735 335326.888 4555584.6535</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300038_PI.108">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334746.937 4555534.3875</gml:lowerCorner>
         <gml:upperCorner>334752.417 4555544.5875</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300038_PI.108</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300038&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300038&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300038_PI.108" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 334749.727 4555544.5175 334750.147 4555544.3275 334750.497 4555544.0375 334750.767 4555543.6675 334750.917 4555543.2375 334750.957 4555542.7775 334751.537 4555542.8475 334752.417 4555534.8975 334747.817 4555534.3875 334746.937 4555542.3375 334747.577 4555542.4075 334747.517 4555542.8675 334747.577 4555543.3175 334747.757 4555543.7375 334748.037 4555544.0975 334748.397 4555544.3675 334748.827 4555544.5375 334749.277 4555544.5875 334749.727 4555544.5175</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300049_PI.109">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334486.675 4555577.8285</gml:lowerCorner>
         <gml:upperCorner>334489.6145 4555583.0795</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300049_PI.109</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300049_PI.109" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334486.675 4555577.9705 334486.9475 4555583.0795 334489.6145 4555582.937 334489.342 4555577.8285 334486.675 4555577.9705</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300062_PI.110">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334679.84 4555828.1</gml:lowerCorner>
         <gml:upperCorner>334687.69 4555837.3</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300062_PI.110</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300062&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300062&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300062_PI.110" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="47"> 334681.2 4555836.82 334681.44 4555836.97 334681.7 4555837.08 334681.97 4555837.18 334682.25 4555837.24 334682.81 4555837.3 334683.65 4555837.18 334684.17 4555836.97 334684.65 4555836.66 334685.02 4555836.37 334685.78 4555835.43 334686.35 4555834.56 334686.83 4555833.63 334687.23 4555832.66 334687.53 4555831.66 334687.69 4555830.65 334687.67 4555829.99 334687.5 4555829.39 334687.16 4555828.86 334686.86 4555828.57 334686.69 4555828.45 334686.12 4555828.19 334685.92 4555828.14 334685.5 4555828.1 334685.09 4555828.13 334684.88 4555828.18 334684.31 4555828.44 334683.98 4555828.7 334683.7 4555829.01 334683.49 4555829.37 334683.15 4555830.37 334682.93 4555830.73 334682.66 4555831.05 334682.15 4555831.41 334681.7 4555831.56 334681.2 4555831.82 334680.75 4555832.17 334680.38 4555832.59 334680.1 4555833.08 334679.92 4555833.62 334679.84 4555834.18 334679.86 4555834.74 334679.92 4555835.02 334680.1 4555835.56 334680.38 4555836.05 334680.75 4555836.48 334681.2 4555836.82</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300079_PI.111">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334476.52 4555514.84</gml:lowerCorner>
         <gml:upperCorner>334482.45 4555521.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300079_PI.111</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300079&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300079&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300079_PI.111" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="46"> 334481.63 4555521.02 334481.83 4555520.88 334482 4555520.7 334482.13 4555520.49 334482.23 4555520.27 334482.25 4555520.15 334482.28 4555519.9 334482.26 4555519.65 334482.04 4555519 334481.99 4555518.5 334482.09 4555518.01 334482.38 4555517.43 334482.45 4555517.19 334482.44 4555516.94 334482.33 4555516.63 334482.1 4555516.38 334481.88 4555516.26 334481.72 4555516.22 334481.47 4555516.22 334480.98 4555516.33 334480.46 4555516.37 334478.91 4555515.34 334478.75 4555515.06 334478.55 4555514.91 334478.3 4555514.84 334478.11 4555514.85 334477.93 4555514.91 334477.73 4555515.07 334477.66 4555515.18 334477.58 4555515.42 334477.58 4555515.72 334476.61 4555517.45 334476.52 4555517.74 334476.53 4555517.97 334476.6 4555518.18 334476.78 4555518.41 334477.04 4555518.56 334477.26 4555518.6 334477.6 4555518.6 334479.82 4555520.48 334480.04 4555520.79 334480.33 4555521.02 334480.55 4555521.12 334480.91 4555521.19 334481.28 4555521.16 334481.63 4555521.02</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300079_PI.112">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334506.02 4555530.61</gml:lowerCorner>
         <gml:upperCorner>334513.85 4555536.18</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300079_PI.112</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300079&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300079&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300079_PI.112" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30"> 334513.67 4555535.71 334513.77 4555535.53 334513.83 4555535.34 334513.85 4555535.04 334513.74 4555534.65 334513.57 4555534.4 334513.44 4555534.27 334513.53 4555532.36 334507.33 4555530.61 334507.1 4555530.62 334506.88 4555530.69 334506.69 4555530.82 334506.54 4555531 334506.45 4555531.22 334506.1 4555533.94 334506.04 4555534.08 334506.02 4555534.23 334506.08 4555534.47 334506.28 4555534.68 334506.47 4555534.74 334506.71 4555534.72 334511.74 4555535.3 334511.89 4555535.68 334512.08 4555535.91 334512.33 4555536.08 334512.62 4555536.17 334512.82 4555536.18 334513.12 4555536.13 334513.39 4555536 334513.67 4555535.71</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02300087_PI.113">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334530.8865 4555752.244</gml:lowerCorner>
         <gml:upperCorner>334536.5135 4555757.496</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02300087_PI.113</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02300087&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02300087&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02300087_PI.113" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26"> 334536.209 4555752.707 334535.297 4555752.3355 334534.4485 4555752.244 334533.6025 4555752.3525 334532.8045 4555752.6545 334532.099 4555753.1345 334531.525 4555753.7655 334531.2085 4555754.298 334531.113 4555754.5125 334530.8865 4555755.335 334530.983 4555756.144 334531.047 4555756.3675 334531.2 4555756.686 334531.5875 4555757.1235 334532.0995 4555757.404 334532.676 4555757.496 334533.561 4555757.4855 334534.359 4555757.2785 334534.707 4555757.1185 334535.084 4555756.886 334535.6935 4555756.33 334536.1505 4555755.644 334536.4295 4555754.868 334536.5135 4555754.0475 334536.397 4555753.231 334536.209 4555752.707</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500001_PI.114">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334305.2 4558006.4</gml:lowerCorner>
         <gml:upperCorner>334314.45 4558018.79</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500001_PI.114</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500001_PI.114" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334314.45 4558008.47 334309.84 4558006.4 334305.2 4558016.72 334309.81 4558018.79 334314.45 4558008.47</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500004_PI.115">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334731.44 4558029.35</gml:lowerCorner>
         <gml:upperCorner>334740.86 4558041.13</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500004_PI.115</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500004&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500004&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500004_PI.115" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334737.31 4558041.13 334740.86 4558031.52 334735 4558029.35 334731.44 4558038.96 334737.31 4558041.13</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500007_PI.116">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334767.6055 4557948.411</gml:lowerCorner>
         <gml:upperCorner>334774.8055 4557956.451</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500007_PI.116</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500007_PI.116" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334774.8055 4557950.621 334771.4755 4557948.411 334767.6055 4557954.241 334770.9355 4557956.451 334774.8055 4557950.621</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500009_PI.117">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334937.42 4557664</gml:lowerCorner>
         <gml:upperCorner>334948.81 4557674.24</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500009_PI.117</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500009&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500009&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500009_PI.117" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334948.81 4557669.91 334940.76 4557664 334937.42 4557668.33 334945.47 4557674.24 334948.81 4557669.91</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500032_PI.118">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334770.22 4557202.77</gml:lowerCorner>
         <gml:upperCorner>334783.21 4557213.76</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500032_PI.118</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500032&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500032&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500032_PI.118" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334783.21 4557208.8 334773.97 4557202.77 334770.22 4557207.73 334779.46 4557213.76 334783.21 4557208.8</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500048_PI.119">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334801.793 4557628.5105</gml:lowerCorner>
         <gml:upperCorner>334812.043 4557640.3105</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500048_PI.119</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500048&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500048&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500048_PI.119" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 334805.523 4557630.8005 334801.793 4557637.1305 334806.883 4557640.3105 334812.043 4557631.5605 334806.873 4557628.5105 334805.523 4557630.8005</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500076_PI.120">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335510.814 4556319.953</gml:lowerCorner>
         <gml:upperCorner>335519.334 4556328.633</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500076_PI.120</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500076&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500076&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500076_PI.120" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 335516.184 4556319.983 335515.994 4556319.953 335515.804 4556319.983 335515.624 4556320.053 335515.464 4556320.173 335515.344 4556320.333 335515.274 4556320.513 335515.244 4556320.703 335515.274 4556320.903 335515.344 4556321.083 335515.464 4556321.233 335510.814 4556325.773 335513.614 4556328.633 335519.334 4556323.043 335516.534 4556320.183 335516.374 4556320.053 335516.184 4556319.983</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500079_PI.121">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335295.065 4556472.845</gml:lowerCorner>
         <gml:upperCorner>335304.595 4556483.315</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500079_PI.121</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500079&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500079&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500079_PI.121" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 335300.115 4556483.315 335304.595 4556479.025 335298.685 4556472.845 335295.065 4556476.305 335299.665 4556481.115 335298.795 4556481.945 335300.115 4556483.315</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02500085_PI.122">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334283.27 4557901.72</gml:lowerCorner>
         <gml:upperCorner>334290.96 4557911.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02500085_PI.122</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02500085&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02500085&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02500085_PI.122" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334283.27 4557909.79 334286.58 4557911.58 334290.96 4557903.51 334287.65 4557901.72 334283.27 4557909.79</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600007_PI.123">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334602.91 4558660.85</gml:lowerCorner>
         <gml:upperCorner>334613.69 4558670.77</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600007_PI.123</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600007_PI.123" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 334613.69 4558664.89 334608.46 4558660.85 334602.91 4558668.04 334606.44 4558670.77 334610.8 4558665.12 334612.5 4558666.44 334613.69 4558664.89</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600009_PI.124">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334741.2985 4558862.135</gml:lowerCorner>
         <gml:upperCorner>334749.084 4558870.1135</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600009_PI.124</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600009&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600009&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600009_PI.124" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334746.743 4558862.135 334741.2985 4558867.7345 334743.3235 4558870.1135 334749.084 4558864.566 334746.743 4558862.135</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600011_PI.125">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334824.382 4558776.402</gml:lowerCorner>
         <gml:upperCorner>334834.652 4558787.012</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600011_PI.125</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600011&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600011&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600011_PI.125" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334827.842 4558787.012 334834.652 4558779.602 334831.182 4558776.402 334824.382 4558783.802 334827.842 4558787.012</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600014_PI.126">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334941.3415 4558698.411</gml:lowerCorner>
         <gml:upperCorner>334949.8215 4558707.291</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600014_PI.126</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600014&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600014&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600014_PI.126" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334949.8215 4558704.591 334944.4415 4558698.411 334941.3415 4558701.101 334946.7215 4558707.291 334949.8215 4558704.591</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600015_PI.127">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335007.45 4558643.54</gml:lowerCorner>
         <gml:upperCorner>335016.69 4558651.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600015_PI.127</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600015&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600015&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600015_PI.127" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335016.69 4558647 335013.15 4558643.54 335007.45 4558648.53 335010.99 4558651.98 335016.69 4558647</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600016_PI.128">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334984.46 4558511.87</gml:lowerCorner>
         <gml:upperCorner>334992.78 4558521.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600016_PI.128</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600016_PI.128" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 334992.72 4558520.29 334991.76 4558519.11 334992.78 4558518.33 334987.54 4558511.87 334984.46 4558514.22 334989.81 4558520.85 334990.76 4558520.12 334991.59 4558521.15 334992.72 4558520.29</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600018_PI.129">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335104.63 4558553.15</gml:lowerCorner>
         <gml:upperCorner>335113.48 4558561</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2013-01-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600018_PI.129</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600018&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600018&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600018_PI.129" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 335112.98 4558554.02 335112.68 4558553.85 335112.52 4558553.8 335112.34 4558553.79 335112 4558553.85 335111.77 4558553.97 335111.2 4558553.15 335104.63 4558557.71 335106.91 4558561 335113.48 4558556.43 335112.91 4558555.6 335113.11 4558555.43 335113.21 4558555.29 335113.33 4558554.96 335113.34 4558554.79 335113.33 4558554.62 335113.21 4558554.29 335112.98 4558554.02</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600030_PI.130">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335054.0935 4557944.7495</gml:lowerCorner>
         <gml:upperCorner>335061.8735 4557952.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600030_PI.130</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600030&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600030&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600030_PI.130" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 335054.174 4557951.567 335056.5 4557952.85 335058.425 4557952.289 335061.633 4557948.038 335061.8735 4557946.0325 335060.029 4557944.7495 335057.8635 4557945.07 335054.0935 4557949.241 335054.174 4557951.567</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600033_PI.131">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334903.127 4558130.3805</gml:lowerCorner>
         <gml:upperCorner>334911.027 4558138.7005</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600033_PI.131</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600033_PI.131" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334903.127 4558133.0105 334907.877 4558138.7005 334911.027 4558136.0705 334906.277 4558130.3805 334903.127 4558133.0105</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600033_PI.132">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334916.907 4558093.17</gml:lowerCorner>
         <gml:upperCorner>334928.2165 4558105.8005</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600033_PI.132</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600033_PI.132" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="72"> 334920.967 4558105.6905 334921.277 4558105.7705 334921.677 4558105.8005 334921.947 4558105.7905 334922.547 4558105.6805 334923.147 4558105.4005 334924.027 4558104.7605 334924.527 4558104.2905 334925.187 4558103.5005 334926.827 4558101.38 334927.677 4558100.14 334927.817 4558099.85 334927.947 4558099.24 334927.947 4558098.89 334927.907 4558098.56 334927.837 4558098.25 334927.727 4558097.96 334927.197 4558096.89 334927.1465 4558096.68 334927.1565 4558096.51 334927.1965 4558096.35 334927.3665 4558095.99 334928.0565 4558095.11 334928.1665 4558094.93 334928.2165 4558094.54 334928.1165 4558093.93 334927.9865 4558093.65 334927.8065 4558093.46 334927.5865 4558093.33 334927.3565 4558093.25 334926.8865 4558093.17 334926.3465 4558093.17 334925.8065 4558093.25 334925.5965 4558093.31 334925.4265 4558093.41 334925.1865 4558093.75 334925.0765 4558094.18 334925.0865 4558094.34 334925.1965 4558094.79 334925.2165 4558095.2 334925.1365 4558095.69 334924.9665 4558096.21 334924.8365 4558096.49 334924.3565 4558097.1205 334923.707 4558097.6905 334923.427 4558097.8605 334922.937 4558097.9805 334920.7365 4558097.9405 334920.0065 4558098.0105 334919.7465 4558098.0905 334919.4965 4558098.2105 334918.967 4558098.5705 334918.417 4558099.0905 334917.747 4558099.8805 334917.157 4558100.7305 334916.947 4558101.1905 334916.907 4558101.4105 334916.907 4558101.6405 334916.977 4558101.8505 334917.187 4558102.2105 334917.307 4558102.3405 334917.557 4558102.4905 334918.757 4558102.7005 334919.247 4558102.7505 334919.467 4558102.8105 334919.647 4558102.9305 334919.777 4558103.0805 334919.807 4558103.1705 334919.797 4558103.9805 334919.847 4558104.3805 334919.927 4558104.6005 334920.967 4558105.6905</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600055_PI.133">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335117.345 4558189.652</gml:lowerCorner>
         <gml:upperCorner>335123.184 4558195.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-03-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600055_PI.133</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600055&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600055&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600055_PI.133" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335117.345 4558192.534 335121.028 4558195.29 335123.184 4558192.407 335119.501 4558189.652 335117.345 4558192.534</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600072_PI.134">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335862.22 4557910.51</gml:lowerCorner>
         <gml:upperCorner>335869.24 4557917.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600072_PI.134</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600072&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600072&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600072_PI.134" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335866.74 4557917.56 335869.24 4557915.1 335864.72 4557910.51 335862.22 4557912.98 335866.74 4557917.56</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600083_PI.135">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336080.6895 4556936.0895</gml:lowerCorner>
         <gml:upperCorner>336088.8695 4556944.1695</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600083_PI.135</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600083&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600083&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600083_PI.135" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336086.31 4556944.1695 336088.8695 4556941.4995 336083.2495 4556936.0895 336080.6895 4556938.7595 336086.31 4556944.1695</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600084_PI.136">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336083.16 4556729.75</gml:lowerCorner>
         <gml:upperCorner>336091.83 4556736.06</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600084_PI.136</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600084&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600084&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600084_PI.136" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336091.83 4556732.6 336084.73 4556729.75 336083.16 4556733.22 336090.26 4556736.06 336091.83 4556732.6</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600091_PI.137">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335541.3925 4557406.0445</gml:lowerCorner>
         <gml:upperCorner>335550.6925 4557417.3845</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600091_PI.137</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600091&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600091&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600091_PI.137" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 335542.2225 4557412.5745 335541.3925 4557415.1145 335547.6425 4557417.3845 335550.6925 4557408.4045 335544.3525 4557406.0445 335542.2225 4557412.5745</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600112_PI.138">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334673.5 4558576.533</gml:lowerCorner>
         <gml:upperCorner>334681.58 4558585.023</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600112_PI.138</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600112&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600112&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600112_PI.138" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 334680.89 4558576.953 334678.68 4558576.533 334677.67 4558577.883 334677.27 4558579.643 334676.21 4558580.673 334675.1 4558581.323 334673.57 4558582.913 334673.5 4558584.373 334673.93 4558584.643 334675.25 4558585.023 334676.59 4558584.763 334678.5 4558583.383 334681.18 4558580.393 334681.58 4558578.573 334680.89 4558576.953</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600118_PI.139">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334632.22 4558597.873</gml:lowerCorner>
         <gml:upperCorner>334639.75 4558605.183</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600118_PI.139</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600118&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600118&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600118_PI.139" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334637.39 4558597.873 334632.22 4558602.603 334634.58 4558605.183 334639.75 4558600.453 334637.39 4558597.873</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600123_PI.140">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336007.487 4557935.052</gml:lowerCorner>
         <gml:upperCorner>336014.697 4557941.642</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600123_PI.140</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600123&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600123&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600123_PI.140" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336007.487 4557938.272 336009.637 4557941.642 336014.697 4557938.4215 336012.547 4557935.052 336007.487 4557938.272</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600125_PI.141">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334619.0585 4558363.207</gml:lowerCorner>
         <gml:upperCorner>334631.1355 4558374.4075</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600125_PI.141</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600125&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600125&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600125_PI.141" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 334626.5145 4558363.8675 334619.0585 4558369.3295 334622.7785 4558374.4075 334630.261 4558368.926 334631.1355 4558368.2855 334627.4155 4558363.207 334626.5145 4558363.8675</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600126_PI.142">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334649.2185 4558360.3925</gml:lowerCorner>
         <gml:upperCorner>334662.4885 4558372.2025</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600126_PI.142</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600126&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600126&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600126_PI.142" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334652.6685 4558372.2025 334662.4885 4558365.3025 334659.0385 4558360.3925 334649.2185 4558367.283 334652.6685 4558372.2025</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02600129_PI.143">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335160.3605 4558522.599</gml:lowerCorner>
         <gml:upperCorner>335168.3005 4558530.149</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-21T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02600129_PI.143</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02600129&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02600129&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02600129_PI.143" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335162.9105 4558530.149 335168.3005 4558525.679 335165.7405 4558522.599 335160.3605 4558527.069 335162.9105 4558530.149</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700010_PI.144">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335461.85 4558988.81</gml:lowerCorner>
         <gml:upperCorner>335467.5 4558997.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700010_PI.144</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700010&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700010&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700010_PI.144" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 335462.13 4558995.1 335461.85 4558996.1 335465.48 4558997.12 335465.9 4558995.62 335467.5 4558989.82 335463.86 4558988.81 335462.13 4558995.1</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700023_PI.145">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336092.02 4557927.96</gml:lowerCorner>
         <gml:upperCorner>336102.84 4557937.32</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700023_PI.145</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700023&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700023&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700023_PI.145" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336094.64 4557937.32 336102.84 4557932.03 336100.22 4557927.96 336092.02 4557933.25 336094.64 4557937.32</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700024_PI.146">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336054.86 4557961.91</gml:lowerCorner>
         <gml:upperCorner>336063.12 4557969.08</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700024_PI.146</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700024&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700024&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700024_PI.146" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336063.12 4557964.98 336060.82 4557961.91 336054.86 4557966.1 336057.1 4557969.08 336063.12 4557964.98</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700039_PI.147">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334913.822 4558814.5315</gml:lowerCorner>
         <gml:upperCorner>334924.0125 4558825.4415</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700039_PI.147</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700039&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700039&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700039_PI.147" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334924.0125 4558822.2915 334917.702 4558814.5315 334913.822 4558817.6915 334920.1325 4558825.4415 334924.0125 4558822.2915</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700044_PI.148">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335126.3935 4558919.79</gml:lowerCorner>
         <gml:upperCorner>335133.3235 4558929.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700044_PI.148</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700044&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700044&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700044_PI.148" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335133.3235 4558928.59 335130.6035 4558919.79 335126.3935 4558921.08 335129.1135 4558929.88 335133.3235 4558928.59</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700045_PI.149">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335144.3635 4558913.4</gml:lowerCorner>
         <gml:upperCorner>335149.6835 4558918.06</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700045_PI.149</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700045&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700045&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700045_PI.149" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335144.3635 4558915.24 335145.7435 4558918.06 335149.6835 4558916.13 335148.3435 4558913.4 335144.3635 4558915.24</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700049_PI.150">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335395.973 4558843.318</gml:lowerCorner>
         <gml:upperCorner>335404.363 4558848.898</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700049_PI.150</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700049_PI.150" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 335395.973 4558848.198 335396.193 4558848.488 335396.493 4558848.718 335396.833 4558848.858 335397.313 4558848.898 335397.553 4558848.858 335397.893 4558848.718 335398.093 4558848.578 335398.273 4558848.398 335398.413 4558848.198 335398.413 4558847.028 335404.363 4558847.028 335404.313 4558843.318 335395.983 4558843.428 335395.973 4558848.198</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700055_PI.151">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335593.7405 4558418.8455</gml:lowerCorner>
         <gml:upperCorner>335599.6305 4558424.3455</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700055_PI.151</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700055&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700055&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700055_PI.151" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335593.7405 4558422.4355 335595.3405 4558424.3455 335599.6305 4558420.7555 335598.03 4558418.8455 335593.7405 4558422.4355</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02700074_PI.152">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335048.103 4558912.8205</gml:lowerCorner>
         <gml:upperCorner>335056.843 4558923.1105</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-21T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02700074_PI.152</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02700074&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02700074&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02700074_PI.152" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335052.473 4558912.8205 335048.103 4558915.2405 335052.463 4558923.1105 335056.843 4558920.6905 335052.473 4558912.8205</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800020_PI.153">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335122.2345 4559098.4</gml:lowerCorner>
         <gml:upperCorner>335131.2545 4559105.0905</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800020_PI.153</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800020_PI.153" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335131.2545 4559102.47 335129.8545 4559098.4 335122.2345 4559101.0205 335123.6345 4559105.0905 335131.2545 4559102.47</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800026_PI.154">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334929.8145 4559140.752</gml:lowerCorner>
         <gml:upperCorner>334935.4045 4559145.162</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800026_PI.154</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800026&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800026&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800026_PI.154" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334930.4945 4559145.162 334935.4045 4559144.182 334934.7145 4559140.752 334929.8145 4559141.732 334930.4945 4559145.162</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800034_PI.155">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335070.8965 4559345.711</gml:lowerCorner>
         <gml:upperCorner>335079.9365 4559353.881</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800034_PI.155</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800034&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800034&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800034_PI.155" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335070.8965 4559349.891 335073.6765 4559353.881 335079.9365 4559349.451 335077.2965 4559345.711 335070.8965 4559349.891</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800039_PI.156">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335041.6365 4559359.8215</gml:lowerCorner>
         <gml:upperCorner>335048.8265 4559366.6315</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800039_PI.156</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800039&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800039&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800039_PI.156" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335048.8265 4559363.0115 335046.4165 4559359.8215 335041.6365 4559363.4415 335044.0465 4559366.6315 335048.8265 4559363.0115</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800040_PI.157">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335032.75 4559248.85</gml:lowerCorner>
         <gml:upperCorner>335036.36 4559254.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800040_PI.157</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800040&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800040&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800040_PI.157" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335033.08 4559254.56 335036.36 4559254.35 335036.03 4559248.85 335032.75 4559249.06 335033.08 4559254.56</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800042_PI.158">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334973.9755 4559247.7815</gml:lowerCorner>
         <gml:upperCorner>334982.7755 4559253.8415</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800042_PI.158</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800042&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800042&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800042_PI.158" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334982.7755 4559251.6215 334981.6655 4559247.7815 334973.9755 4559250.0015 334975.0855 4559253.8415 334982.7755 4559251.6215</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800043_PI.159">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334961.3355 4559258.0415</gml:lowerCorner>
         <gml:upperCorner>334970.1855 4559264.322</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800043_PI.159</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800043&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800043&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800043_PI.159" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334970.1855 4559261.8415 334968.9455 4559258.0415 334961.3355 4559260.522 334962.5755 4559264.322 334970.1855 4559261.8415</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800046_PI.160">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335053.0365 4559354.221</gml:lowerCorner>
         <gml:upperCorner>335059.2365 4559360.621</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800046_PI.160</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800046_PI.160" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335059.2365 4559358.231 335056.2465 4559354.221 335053.0365 4559356.611 335056.0265 4559360.621 335059.2365 4559358.231</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800048_PI.161">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334926.78 4559278.41</gml:lowerCorner>
         <gml:upperCorner>334934.42 4559286.31</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800048_PI.161</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800048&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800048&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800048_PI.161" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334934.42 4559283.49 334930.1 4559278.41 334926.78 4559281.23 334931.1 4559286.31 334934.42 4559283.49</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800049_PI.162">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335043.407 4559426.6515</gml:lowerCorner>
         <gml:upperCorner>335051.397 4559435.4015</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800049_PI.162</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800049_PI.162" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335051.397 4559432.9915 335047.387 4559426.6515 335043.407 4559429.1615 335047.347 4559435.4015 335051.397 4559432.9915</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800052_PI.163">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335028.8665 4559380.5015</gml:lowerCorner>
         <gml:upperCorner>335036.8065 4559389.7415</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800052_PI.163</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800052&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800052&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800052_PI.163" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335028.8665 4559382.6215 335033.6465 4559389.7415 335036.8065 4559387.6215 335032.0265 4559380.5015 335028.8665 4559382.6215</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800053_PI.164">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334975.198 4559342.436</gml:lowerCorner>
         <gml:upperCorner>334982.7135 4559349.7935</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800053_PI.164</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800053&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800053&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800053_PI.164" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334977.785 4559349.7935 334982.7135 4559345.23 334980.1265 4559342.436 334975.198 4559346.9995 334977.785 4559349.7935</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800058_PI.165">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334982.506 4559276.8915</gml:lowerCorner>
         <gml:upperCorner>334992.096 4559285.8015</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-26T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800058_PI.165</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800058&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800058&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800058_PI.165" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="37"> 334991.546 4559278.7815 334991.036 4559278.2515 334990.716 4559277.9815 334989.766 4559277.3415 334989.346 4559277.1215 334989.046 4559277.0215 334988.276 4559276.8915 334987.496 4559276.9715 334986.756 4559277.2415 334986.116 4559277.6815 334984.456 4559279.6715 334983.726 4559280.7415 334983.496 4559281.1215 334982.686 4559282.7415 334982.516 4559283.3715 334982.506 4559284.0915 334982.706 4559284.7815 334982.966 4559285.2615 334983.086 4559285.3915 334983.386 4559285.6215 334983.906 4559285.8015 334984.456 4559285.7915 334984.956 4559285.5815 334985.836 4559284.7215 334986.046 4559284.5715 334986.466 4559284.3615 334987.166 4559284.1915 334988.156 4559284.1815 334989.116 4559283.9715 334990.006 4559283.5715 334990.806 4559283.0015 334991.466 4559282.2815 334991.836 4559281.7015 334992.076 4559280.9215 334992.096 4559280.1615 334991.916 4559279.4315 334991.546 4559278.7815</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02800060_PI.166">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334913.3255 4559261.742</gml:lowerCorner>
         <gml:upperCorner>334919.9655 4559270.652</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-26T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02800060_PI.166</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02800060&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02800060&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02800060_PI.166" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334917.0455 4559261.742 334913.3255 4559263.202 334916.2455 4559270.652 334919.9655 4559269.192 334917.0455 4559261.742</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02900052_PI.167">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335741.31 4559567.39</gml:lowerCorner>
         <gml:upperCorner>335746.03 4559573.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02900052_PI.167</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02900052&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02900052&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02900052_PI.167" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335746.03 4559568.45 335743.68 4559567.39 335741.31 4559572.63 335743.67 4559573.69 335746.03 4559568.45</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A02900089_PI.168">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335332.139 4559843.7135</gml:lowerCorner>
         <gml:upperCorner>335341.6345 4559852.9175</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-12-20T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A02900089_PI.168</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A02900089&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A02900089&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A02900089_PI.168" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335335.3115 4559852.9175 335341.6345 4559847.6155 335338.362 4559843.7135 335332.139 4559849.36 335335.3115 4559852.9175</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03000046_PI.169">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335706.8045 4558985.3455</gml:lowerCorner>
         <gml:upperCorner>335715.955 4558993.7355</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03000046_PI.169</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03000046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03000046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03000046_PI.169" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335706.8045 4558988.4355 335713.515 4558993.7355 335715.955 4558990.6455 335709.2445 4558985.3455 335706.8045 4558988.4355</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03000049_PI.170">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335735.165 4558983.1355</gml:lowerCorner>
         <gml:upperCorner>335740.745 4558988.7155</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03000049_PI.170</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03000049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03000049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03000049_PI.170" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335735.165 4558986.3955 335738.425 4558988.7155 335740.745 4558985.4555 335737.485 4558983.1355 335735.165 4558986.3955</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03100011_PI.171">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337005.44 4558766.44</gml:lowerCorner>
         <gml:upperCorner>337010.5 4558775.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-11-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03100011_PI.171</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03100011&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03100011&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03100011_PI.171" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 337007.11 4558775.54 337007.37 4558775.52 337007.69 4558775.38 337007.94 4558775.14 337008.08 4558774.86 337008.7 4558775 337010.5 4558767.19 337007.24 4558766.44 337005.44 4558774.26 337006.21 4558774.44 337006.2 4558774.63 337006.23 4558774.81 337006.37 4558775.13 337006.48 4558775.26 337006.69 4558775.42 337006.85 4558775.49 337007.11 4558775.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03100019_PI.172">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336688.1295 4558081.537</gml:lowerCorner>
         <gml:upperCorner>336696.8995 4558087.617</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03100019_PI.172</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03100019&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03100019&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03100019_PI.172" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336696.8995 4558085.937 336695.9495 4558081.537 336688.1295 4558083.217 336689.0795 4558087.617 336696.8995 4558085.937</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03100027_PI.173">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336771.17 4558531.29</gml:lowerCorner>
         <gml:upperCorner>336778.77 4558534.99</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03100027_PI.173</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03100027&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03100027&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03100027_PI.173" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336778.77 4558531.35 336771.2 4558531.29 336771.17 4558534.94 336778.74 4558534.99 336778.77 4558531.35</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03100028_PI.174">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336852.516 4558922.157</gml:lowerCorner>
         <gml:upperCorner>336857.166 4558931.907</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03100028_PI.174</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03100028&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03100028&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03100028_PI.174" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336857.166 4558931.877 336857.096 4558922.157 336852.516 4558922.187 336852.586 4558931.907 336857.166 4558931.877</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03200003_PI.175">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337329.9835 4557169.1505</gml:lowerCorner>
         <gml:upperCorner>337338.9835 4557180.3305</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03200003_PI.175</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03200003&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03200003&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03200003_PI.175" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337338.9835 4557171.4205 337334.5335 4557169.1505 337329.9835 4557178.0605 337334.4435 4557180.3305 337338.9835 4557171.4205</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03300007_PI.176">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337411.272 4556260.8305</gml:lowerCorner>
         <gml:upperCorner>337420.9005 4556271.773</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03300007_PI.176</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03300007&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03300007&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03300007_PI.176" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337415.5445 4556260.8305 337411.272 4556268.9565 337416.628 4556271.773 337420.9005 4556263.6465 337415.5445 4556260.8305</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03300039_PI.177">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337389.297 4556318.789</gml:lowerCorner>
         <gml:upperCorner>337398.667 4556327.299</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03300039_PI.177</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03300039&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03300039&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03300039_PI.177" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337398.667 4556324.309 337391.957 4556318.789 337389.297 4556321.779 337396.007 4556327.299 337398.667 4556324.309</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400002_PI.178">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337730.654 4555848.2055</gml:lowerCorner>
         <gml:upperCorner>337737.794 4555856.9955</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400002_PI.178</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400002&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400002&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400002_PI.178" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 337731.744 4555849.3055 337732.574 4555852.1855 337730.654 4555852.7455 337731.204 4555854.6655 337733.124 4555854.1155 337733.954 4555856.9955 337737.794 4555855.8955 337735.594 4555848.2055 337731.744 4555849.3055</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400006_PI.179">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338258.2195 4556014.1625</gml:lowerCorner>
         <gml:upperCorner>338272.69 4556022.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400006_PI.179</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400006&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400006&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400006_PI.179" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 338258.2195 4556014.1625 338258.25 4556014.29 338258.28 4556014.29 338258.28 4556014.42 338259.77 4556021.48 338266.82 4556021.62 338266.93 4556022.15 338272.69 4556021.73 338271.3895 4556016.775 338262.056 4556015.352 338260.836 4556015.162 338258.266 4556014.172 338258.2195 4556014.1625</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400023_PI.180">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337629.768 4555073.465</gml:lowerCorner>
         <gml:upperCorner>337638.378 4555080.355</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400023_PI.180</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400023&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400023&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400023_PI.180" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337629.768 4555076.365 337636.708 4555080.355 337638.378 4555077.455 337631.438 4555073.465 337629.768 4555076.365</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400026_PI.181">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337570.34 4555065.84</gml:lowerCorner>
         <gml:upperCorner>337579.7 4555072.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400026_PI.181</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400026&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400026&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400026_PI.181" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337578.31 4555072.54 337579.7 4555068.82 337571.73 4555065.84 337570.34 4555069.56 337578.31 4555072.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400029_PI.182">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337639.04 4555339.5555</gml:lowerCorner>
         <gml:upperCorner>337648.95 4555345.3455</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400029_PI.182</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400029&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400029&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400029_PI.182" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="51"> 337648.95 4555341.9255 337648.91 4555341.6255 337648.74 4555341.1055 337648.49 4555340.6455 337648.34 4555340.4555 337648.16 4555340.2955 337647.95 4555340.1555 337647.1 4555339.7255 337646.79 4555339.6155 337646.5 4555339.5555 337646.2 4555339.5555 337645.58 4555339.6455 337643.33 4555340.1355 337641.93 4555339.9755 337641.06 4555339.9755 337640.51 4555340.0955 337640.12 4555340.2655 337639.83 4555340.4755 337639.4 4555340.9855 337639.13 4555341.5655 337639.06 4555341.8955 337639.04 4555342.2355 337639.08 4555342.5755 337639.19 4555342.9155 337639.35 4555343.2155 337639.56 4555343.4955 337640.07 4555343.9355 337640.7 4555344.3455 337640.84 4555344.4855 337641.12 4555345.0055 337641.24 4555345.1355 337641.55 4555345.2855 337641.9 4555345.3455 337642.29 4555345.3055 337642.66 4555345.1855 337642.92 4555345.0555 337643.1 4555344.9055 337643.37 4555344.7855 337643.92 4555344.7155 337645.72 4555344.7855 337646.05 4555344.7655 337646.36 4555344.7255 337646.66 4555344.6455 337647.27 4555344.3855 337647.59 4555344.1955 337648.21 4555343.7255 337648.45 4555343.4755 337648.64 4555343.2155 337648.78 4555342.9255 337648.89 4555342.5955 337648.95 4555341.9255</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400044_PI.183">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338082.915 4555909.203</gml:lowerCorner>
         <gml:upperCorner>338090.605 4555920.763</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-04-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400044_PI.183</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400044&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400044&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400044_PI.183" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338082.915 4555919.363 338087.495 4555920.763 338090.605 4555910.603 338086.015 4555909.203 338082.915 4555919.363</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400046_PI.184">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338202.0245 4555821.012</gml:lowerCorner>
         <gml:upperCorner>338210.6045 4555829.132</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400046_PI.184</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400046_PI.184" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338202.0245 4555825.432 338207.7445 4555829.132 338210.6045 4555824.712 338204.8845 4555821.012 338202.0245 4555825.432</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400053_PI.185">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337904.03 4555425.95</gml:lowerCorner>
         <gml:upperCorner>337915.84 4555435.23</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-03-05T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400053_PI.185</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400053&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400053&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400053_PI.185" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337904.03 4555429.89 337913.65 4555435.23 337915.84 4555431.29 337906.22 4555425.95 337904.03 4555429.89</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400080_PI.186">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337526.31 4554934.29</gml:lowerCorner>
         <gml:upperCorner>337535.42 4554940.42</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400080_PI.186</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400080&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400080&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400080_PI.186" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 337535.27 4554939.3 337535.39 4554938.98 337535.42 4554938.54 337535.34 4554938.22 337535.24 4554938.02 337535.11 4554937.84 337534.85 4554937.62 337535.03 4554937.15 337527.56 4554934.29 337526.31 4554937.56 337533.78 4554940.42 337533.96 4554939.95 337534.29 4554939.96 337534.62 4554939.88 337534.82 4554939.78 337535.07 4554939.57 337535.27 4554939.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03400082_PI.187">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338077.2445 4555809.333</gml:lowerCorner>
         <gml:upperCorner>338085.8745 4555818.343</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03400082_PI.187</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03400082&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03400082&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03400082_PI.187" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338085.8745 4555811.983 338082.884 4555809.333 338077.2445 4555815.693 338080.2345 4555818.343 338085.8745 4555811.983</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500001_PI.188">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337818.878 4555019.4035</gml:lowerCorner>
         <gml:upperCorner>337827.268 4555034.3635</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500001_PI.188</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500001_PI.188" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 337818.878 4555031.4035 337820.208 4555031.6535 337819.838 4555033.6635 337823.608 4555034.3635 337824.038 4555032.0135 337825.098 4555032.2135 337827.268 4555020.5435 337821.108 4555019.4035 337818.878 4555031.4035</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500006_PI.189">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338098.3615 4555191.083</gml:lowerCorner>
         <gml:upperCorner>338104.8015 4555197.2905</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500006_PI.189</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500006&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500006&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500006_PI.189" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 338098.491 4555196.3335 338099.629 4555197.2905 338100.4825 4555197.2905 338101.372 4555197.2075 338103.172 4555196.3075 338104.1035 4555195.5315 338104.724 4555194.6525 338104.8015 4555193.721 338104.698 4555192.6865 338104.129 4555191.7295 338103.017 4555191.135 338101.7755 4555191.083 338099.008 4555193.2815 338098.491 4555194.187 338098.3615 4555195.247 338098.491 4555196.3335</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500008_PI.190">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338184.3495 4555138.791</gml:lowerCorner>
         <gml:upperCorner>338198.7695 4555145.591</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500008_PI.190</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500008&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500008&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500008_PI.190" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 338184.3495 4555145.591 338186.6895 4555145.591 338186.6895 4555144.641 338189.2395 4555144.641 338189.6395 4555144.261 338198.6495 4555144.321 338198.7695 4555139.141 338184.4295 4555138.791 338184.3495 4555145.591</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500010_PI.191">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338351.2595 4555132.0895</gml:lowerCorner>
         <gml:upperCorner>338360.5195 4555143.2595</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500010_PI.191</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500010&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500010&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500010_PI.191" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338360.5195 4555134.5395 338356.1595 4555132.0895 338351.2595 4555140.8095 338355.6195 4555143.2595 338360.5195 4555134.5395</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500020_PI.192">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338829.919 4554942.906</gml:lowerCorner>
         <gml:upperCorner>338839.399 4554953.656</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500020_PI.192</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500020_PI.192" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338839.399 4554945.6755 338834.079 4554942.906 338829.919 4554950.886 338835.239 4554953.656 338839.399 4554945.6755</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500025_PI.193">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338638.61 4554435.9</gml:lowerCorner>
         <gml:upperCorner>338655.82 4554450.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500025_PI.193</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500025&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500025&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500025_PI.193" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338655.82 4554441.82 338642.21 4554435.9 338638.61 4554444.18 338652.22 4554450.09 338655.82 4554441.82</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500046_PI.194">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338635.528 4554882.1165</gml:lowerCorner>
         <gml:upperCorner>338647.9865 4554894.4685</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500046_PI.194</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500046&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500046&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500046_PI.194" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 338640.004 4554882.2855 338639.562 4554882.1165 338635.528 4554892.6765 338635.551 4554892.6855 338638.809 4554893.93 338639.2405 4554892.7925 338644.569 4554894.4685 338647.9865 4554885.523 338640.004 4554882.2855</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500048_PI.195">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338126.79 4555256.3515</gml:lowerCorner>
         <gml:upperCorner>338133.69 4555264.0115</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-07-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500048_PI.195</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500048&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500048&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500048_PI.195" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 338131.36 4555256.3515 338126.95 4555261.7915 338126.82 4555262.1715 338126.79 4555262.4315 338126.81 4555262.7015 338126.87 4555262.9615 338127.05 4555263.3215 338127.21 4555263.5315 338127.64 4555263.8515 338128.02 4555263.9815 338128.42 4555264.0115 338128.81 4555263.9315 338129.06 4555263.8215 338129.28 4555263.6815 338133.69 4555258.2415 338131.36 4555256.3515</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500057_PI.196">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338755.83 4555668.72</gml:lowerCorner>
         <gml:upperCorner>338764.24 4555682.59</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500057_PI.196</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500057&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500057&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500057_PI.196" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="36"> 338764.24 4555670.11 338759.35 4555668.72 338757.05 4555676.82 338757.11 4555677.75 338757.06 4555678.26 338756.95 4555678.58 338756.78 4555678.87 338756.09 4555679.61 338755.89 4555680.01 338755.83 4555680.44 338755.88 4555680.87 338756.05 4555681.26 338756.33 4555681.61 338756.7 4555681.83 338756.95 4555681.94 338757.11 4555681.97 338757.53 4555681.98 338758.24 4555681.83 338758.6 4555682.22 338758.84 4555682.38 338759.22 4555682.55 338759.38 4555682.58 338759.8 4555682.59 338760.09 4555682.53 338760.48 4555682.33 338760.7 4555682.15 338760.88 4555681.93 338761.08 4555681.53 338761.11 4555681.39 338761.22 4555680.22 338761.22 4555679.71 338761.31 4555679.2 338761.51 4555678.72 338761.79 4555678.3 338761.96 4555678.11 338764.24 4555670.11</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500058_PI.197">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338823.2155 4555606.465</gml:lowerCorner>
         <gml:upperCorner>338832.358 4555618.5115</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-25T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500058_PI.197</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500058&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500058&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500058_PI.197" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 338825.3665 4555616.855 338826.378 4555618.1025 338827.3675 4555618.5115 338830.0135 4555618.4685 338831.1965 4555618.081 338831.541 4555616.059 338832.358 4555612.0795 338831.799 4555610.7245 338828.8945 4555609.821 338826.722 4555608.1645 338826.421 4555606.5295 338824.4415 4555606.465 338823.8395 4555607.089 338823.2155 4555608.896 338824.5705 4555609.606 338825.5175 4555612.6175 338824.915 4555613.2625 338824.8075 4555616.1235 338825.3665 4555616.855</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500062_PI.198">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338171.6955 4555262.777</gml:lowerCorner>
         <gml:upperCorner>338178.738 4555269.202</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-10-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500062_PI.198</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500062&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500062&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500062_PI.198" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338173.6215 4555262.777 338171.6955 4555265.307 338176.812 4555269.202 338178.738 4555266.6715 338173.6215 4555262.777</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03500078_PI.199">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338915.101 4555210.7455</gml:lowerCorner>
         <gml:upperCorner>338921.271 4555220.9155</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03500078_PI.199</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03500078&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03500078&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03500078_PI.199" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338921.271 4555211.5755 338916.841 4555210.7455 338915.101 4555220.0855 338919.531 4555220.9155 338921.271 4555211.5755</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600012_PI.200">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338885.754 4554264.7345</gml:lowerCorner>
         <gml:upperCorner>338890.884 4554269.3345</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600012_PI.200</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600012&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600012&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600012_PI.200" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338885.754 4554267.3045 338889.504 4554269.3345 338890.884 4554266.7545 338887.134 4554264.7345 338885.754 4554267.3045</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600015_PI.201">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339176.37 4554118.07</gml:lowerCorner>
         <gml:upperCorner>339190.57 4554130.49</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600015_PI.201</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600015&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600015&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600015_PI.201" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339179.64 4554118.07 339176.37 4554122.6 339187.3 4554130.49 339190.57 4554125.96 339179.64 4554118.07</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600025_PI.202">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339587.449 4553480.4775</gml:lowerCorner>
         <gml:upperCorner>339597.679 4553494.1375</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600025_PI.202</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600025&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600025&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600025_PI.202" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339587.449 4553491.838 339592.449 4553494.1375 339597.679 4553482.7775 339592.679 4553480.4775 339587.449 4553491.838</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600032_PI.203">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339511.864 4552856.0075</gml:lowerCorner>
         <gml:upperCorner>339523.044 4552866.5775</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600032_PI.203</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600032&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600032&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600032_PI.203" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339511.864 4552860.0675 339519.644 4552866.5775 339523.044 4552862.5175 339515.264 4552856.0075 339511.864 4552860.0675</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600033_PI.204">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339472.39 4552746.35</gml:lowerCorner>
         <gml:upperCorner>339483.38 4552762.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600033_PI.204</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600033_PI.204" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="32"> 339479.1 4552762.37 339483.38 4552751.83 339481.22 4552750.96 339481.43 4552750.25 339481.45 4552750.03 339481.43 4552749.81 339481.32 4552749.5 339481.2 4552749.32 339480.96 4552749.09 339480.66 4552748.94 339480.45 4552748.89 339480.12 4552748.89 339479.8 4552748.99 339479.61 4552749.1 339479.37 4552749.33 339479.26 4552749.51 339479.17 4552749.72 339479.1 4552750.1 339477.6 4552749.58 339477.45 4552748.25 339477.2 4552747.44 339476.89 4552746.98 339476.29 4552746.46 339475.55 4552746.35 339474.92 4552746.81 339474.67 4552747.41 339474.67 4552747.9 339474.99 4552748.49 339475.55 4552749.09 339476.37 4552749.85 339472.39 4552759.64 339479.1 4552762.37</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600052_PI.205">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339346.3535 4552797.3885</gml:lowerCorner>
         <gml:upperCorner>339356.8235 4552809.0385</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-21T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600052_PI.205</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600052&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600052&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600052_PI.205" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339351.7935 4552797.3885 339346.3535 4552805.7785 339351.3835 4552809.0385 339356.8235 4552800.6585 339351.7935 4552797.3885</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600058_PI.206">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339403.877 4553225.0985</gml:lowerCorner>
         <gml:upperCorner>339416.407 4553235.2985</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600058_PI.206</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600058&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600058&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600058_PI.206" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339403.877 4553230.509 339413.787 4553235.2985 339416.407 4553229.8885 339406.4965 4553225.0985 339403.877 4553230.509</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600059_PI.207">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339436.6 4553346.07</gml:lowerCorner>
         <gml:upperCorner>339447.81 4553353.86</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600059_PI.207</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600059&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600059&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600059_PI.207" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 339447.56 4553352.55 339447.69 4553352.31 339447.78 4553352.04 339447.81 4553351.76 339447.76 4553351.35 339447.59 4553350.96 339447.42 4553350.74 339446.8 4553350.26 339447.12 4553349.43 339438.28 4553346.07 339436.6 4553350.49 339445.45 4553353.86 339445.74 4553353.11 339446.24 4553353.2 339446.66 4553353.17 339446.92 4553353.08 339447.17 4553352.95 339447.38 4553352.77 339447.56 4553352.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03600062_PI.208">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>339239.87 4553263.3</gml:lowerCorner>
         <gml:upperCorner>339248.52 4553272.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03600062_PI.208</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03600062&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03600062&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03600062_PI.208" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 339243.26 4553272.29 339248.52 4553266.26 339245.13 4553263.3 339239.87 4553269.33 339243.26 4553272.29</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03700002_PI.209">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338864.1 4552880.68</gml:lowerCorner>
         <gml:upperCorner>338871.05 4552889.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03700002_PI.209</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03700002&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03700002&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03700002_PI.209" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338864.1 4552887.95 338867.73 4552889.61 338871.05 4552882.33 338867.41 4552880.68 338864.1 4552887.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03700032_PI.210">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338457.37 4553911.55</gml:lowerCorner>
         <gml:upperCorner>338472.5 4553924.6</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03700032_PI.210</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03700032&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03700032&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03700032_PI.210" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 338472.5 4553919.3 338460.93 4553911.55 338460.09 4553912.79 338459.76 4553912.76 338459.26 4553912.84 338458.79 4553913.07 338458.4 4553913.41 338458.1 4553913.83 338457.94 4553914.33 338457.92 4553914.83 338458.03 4553915.33 338458.17 4553915.62 338457.37 4553916.85 338468.95 4553924.6 338472.5 4553919.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03700087_PI.211">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338906.515 4553117.5825</gml:lowerCorner>
         <gml:upperCorner>338917.815 4553130.8225</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03700087_PI.211</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03700087&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03700087&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03700087_PI.211" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338906.515 4553127.6925 338912.735 4553130.8225 338917.815 4553120.7125 338911.595 4553117.5825 338906.515 4553127.6925</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800029_PI.212">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337602.2445 4554644.8245</gml:lowerCorner>
         <gml:upperCorner>337619.895 4554657.5045</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800029_PI.212</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800029&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800029&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800029_PI.212" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 337603.7645 4554644.8245 337602.2445 4554649.8045 337615.7045 4554653.8345 337615.765 4554655.7245 337616.805 4554657.5045 337618.385 4554657.2945 337619.325 4554656.2945 337619.895 4554654.5145 337619.8945 4554652.6345 337619.5845 4554652.1045 337619.1145 4554651.6345 337617.4345 4554650.7445 337617.2845 4554649.2745 337616.9645 4554648.1745 337614.8745 4554647.3345 337613.0945 4554647.3345 337610.3645 4554646.6545 337603.7645 4554644.8245</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800031_PI.213">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337689.0935 4554489.0835</gml:lowerCorner>
         <gml:upperCorner>337696.5935 4554493.4835</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-08-16T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800031_PI.213</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800031&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800031&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800031_PI.213" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337696.3735 4554493.4835 337696.5935 4554489.5035 337689.2835 4554489.0835 337689.0935 4554493.0635 337696.3735 4554493.4835</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800033_PI.214">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337799.689 4554501.3765</gml:lowerCorner>
         <gml:upperCorner>337806.4855 4554511.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800033_PI.214</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800033&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800033&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800033_PI.214" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337802.359 4554501.3765 337799.689 4554510.213 337803.8155 4554511.46 337806.4855 4554502.6235 337802.359 4554501.3765</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800044_PI.215">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338434.5155 4553287.956</gml:lowerCorner>
         <gml:upperCorner>338445.4955 4553298.646</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800044_PI.215</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800044&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800044&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800044_PI.215" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 338434.5155 4553293.286 338441.266 4553298.646 338445.4955 4553293.316 338438.7555 4553287.956 338434.5155 4553293.286</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800052_PI.216">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338133.3355 4553324.6685</gml:lowerCorner>
         <gml:upperCorner>338142.7555 4553335.2685</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-07-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800052_PI.216</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800052&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800052&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800052_PI.216" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 338142.7555 4553327.3985 338139.1755 4553324.6685 338133.4155 4553332.2185 338133.3655 4553332.4285 338133.3355 4553332.8485 338133.3755 4553333.2685 338133.5655 4553333.8785 338133.7855 4553334.2485 338134.0555 4553334.5685 338134.2955 4553334.7785 338134.7455 4553335.0485 338135.1455 4553335.1985 338135.5655 4553335.2685 338135.9855 4553335.2685 338136.6055 4553335.1285 338136.9955 4553334.9485 338142.7555 4553327.3985</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03800057_PI.217">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338057.025 4553261.839</gml:lowerCorner>
         <gml:upperCorner>338065.445 4553269.139</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-02-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03800057_PI.217</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03800057&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03800057&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03800057_PI.217" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 338065.385 4553267.569 338065.445 4553267.019 338065.365 4553266.479 338065.145 4553265.979 338064.935 4553265.679 338064.805 4553265.549 338064.665 4553265.419 338059.375 4553261.839 338057.025 4553265.299 338062.315 4553268.879 338062.825 4553269.079 338063.185 4553269.139 338063.555 4553269.139 338063.915 4553269.069 338064.425 4553268.859 338064.855 4553268.519 338064.975 4553268.379 338065.185 4553268.079 338065.385 4553267.569</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A03900028_PI.218">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337327.57 4554485.01</gml:lowerCorner>
         <gml:upperCorner>337339.07 4554494.06</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A03900028_PI.218</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A03900028&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A03900028&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A03900028_PI.218" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22"> 337337.46 4554493.35 337339.07 4554488.04 337329.1 4554485.01 337327.57 4554490.04 337330.22 4554490.84 337330.13 4554491.47 337330.12 4554491.7 337330.16 4554492.14 337330.28 4554492.57 337330.38 4554492.78 337330.76 4554493.33 337331.1 4554493.62 337331.49 4554493.85 337331.7 4554493.93 337332.13 4554494.04 337332.36 4554494.06 337333.02 4554494 337333.65 4554493.75 337334.01 4554493.49 337334.32 4554493.17 337334.75 4554492.54 337337.46 4554493.35</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04000031_PI.219">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337114.7325 4554437.158</gml:lowerCorner>
         <gml:upperCorner>337123.6125 4554443.538</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04000031_PI.219</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04000031&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04000031&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04000031_PI.219" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337123.6125 4554441.508 337122.4725 4554437.158 337114.7325 4554439.188 337115.8725 4554443.538 337123.6125 4554441.508</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04000062_PI.220">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337760.06 4553045.1</gml:lowerCorner>
         <gml:upperCorner>337761.87 4553051.47</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04000062_PI.220</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04000062&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04000062&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04000062_PI.220" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 337760.9 4553051.47 337761.23 4553051.43 337761.45 4553051.32 337761.64 4553051.15 337761.82 4553050.85 337761.87 4553045.77 337761.73 4553045.52 337761.57 4553045.33 337761.36 4553045.19 337761.04 4553045.1 337760.79 4553045.12 337760.55 4553045.21 337760.35 4553045.36 337760.1 4553045.67 337760.06 4553050.68 337760.17 4553050.98 337760.31 4553051.19 337760.43 4553051.3 337760.65 4553051.42 337760.9 4553051.47</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04000066_PI.221">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337438.574 4553292.0635</gml:lowerCorner>
         <gml:upperCorner>337452.914 4553306.5335</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04000066_PI.221</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04000066&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04000066&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04000066_PI.221" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337444.474 4553292.0635 337438.574 4553300.8035 337446.9745 4553306.5335 337452.914 4553297.8235 337444.474 4553292.0635</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04000070_PI.222">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337133.5085 4553926.087</gml:lowerCorner>
         <gml:upperCorner>337142.0685 4553934.267</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04000070_PI.222</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04000070&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04000070&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04000070_PI.222" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337133.5085 4553930.337 337139.0585 4553934.267 337142.0685 4553930.017 337136.5185 4553926.087 337133.5085 4553930.337</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04000073_PI.223">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337505.996 4553664.933</gml:lowerCorner>
         <gml:upperCorner>337518.9195 4553678.333</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2012-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04000073_PI.223</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04000073&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04000073&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04000073_PI.223" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337510.985 4553678.333 337518.9195 4553669.33 337513.9305 4553664.933 337505.996 4553673.936 337510.985 4553678.333</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100001_PI.224">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336052.1435 4554776.7965</gml:lowerCorner>
         <gml:upperCorner>336062.4435 4554787.6465</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100001_PI.224</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100001&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100001&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100001_PI.224" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336062.4435 4554780.0465 336058.643 4554776.7965 336052.1435 4554784.4065 336055.9535 4554787.6465 336062.4435 4554780.0465</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100011_PI.225">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336396.29 4554374.25</gml:lowerCorner>
         <gml:upperCorner>336406.93 4554385.13</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100011_PI.225</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100011&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100011&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100011_PI.225" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336396.29 4554380.99 336400.98 4554385.13 336406.93 4554378.38 336402.24 4554374.25 336396.29 4554380.99</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100036_PI.226">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336071.1715 4554517.506</gml:lowerCorner>
         <gml:upperCorner>336079.3015 4554525.946</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100036_PI.226</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100036&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100036&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100036_PI.226" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336075.8115 4554525.946 336079.3015 4554520.456 336074.6715 4554517.506 336071.1715 4554522.986 336075.8115 4554525.946</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100040_PI.227">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336276.9705 4554384.724</gml:lowerCorner>
         <gml:upperCorner>336284.4205 4554392.934</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100040_PI.227</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100040&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100040&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100040_PI.227" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336276.9705 4554390.564 336280.5605 4554392.934 336284.4205 4554387.084 336280.8305 4554384.724 336276.9705 4554390.564</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100047_PI.228">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336349.65 4554277.25</gml:lowerCorner>
         <gml:upperCorner>336358.34 4554284.47</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100047_PI.228</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100047&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100047&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100047_PI.228" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 336357.97 4554283.38 336358.18 4554283.03 336358.22 4554282.78 336358.12 4554282.38 336358.04 4554282.25 336357.8 4554282 336358.34 4554281.04 336351.57 4554277.25 336349.65 4554280.68 336356.41 4554284.47 336356.92 4554283.55 336357.3 4554283.64 336357.54 4554283.62 336357.7 4554283.57 336357.97 4554283.38</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100058_PI.229">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336328.7805 4554361.0135</gml:lowerCorner>
         <gml:upperCorner>336339.0705 4554371.684</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100058_PI.229</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100058&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100058&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100058_PI.229" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336328.7805 4554367.714 336333.6005 4554371.684 336339.0705 4554365.0435 336334.5805 4554361.3435 336334.1705 4554361.0135 336330.9005 4554365.124 336328.7805 4554367.714</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100059_PI.230">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336297.3505 4554384.534</gml:lowerCorner>
         <gml:upperCorner>336307.7005 4554396.014</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100059_PI.230</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100059&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100059&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100059_PI.230" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336302.9905 4554396.014 336307.7005 4554387.764 336302.0605 4554384.534 336297.3505 4554392.784 336302.9905 4554396.014</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04100060_PI.231">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336390.0505 4554336.333</gml:lowerCorner>
         <gml:upperCorner>336398.8005 4554345.8535</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04100060_PI.231</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04100060&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04100060&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04100060_PI.231" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336398.8005 4554338.823 336395.6805 4554336.333 336390.0505 4554343.3535 336393.1805 4554345.8535 336398.8005 4554338.823</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200005_PI.232">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336764.11 4554928.62</gml:lowerCorner>
         <gml:upperCorner>336770.53 4554934.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200005_PI.232</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200005&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200005&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200005_PI.232" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336770.53 4554930.99 336768.32 4554928.62 336764.11 4554931.82 336766.32 4554934.19 336770.53 4554930.99</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200016_PI.233">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336624.2105 4554290.4215</gml:lowerCorner>
         <gml:upperCorner>336633.0205 4554299.2615</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200016_PI.233</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200016_PI.233" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336624.2105 4554293.0415 336630.3605 4554299.2615 336633.0205 4554296.6415 336626.8705 4554290.4215 336624.2105 4554293.0415</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200019_PI.234">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336515.802 4554537.8225</gml:lowerCorner>
         <gml:upperCorner>336523.912 4554545.4925</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200019_PI.234</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200019&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200019&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200019_PI.234" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 336517.652 4554545.4925 336518.542 4554545.1325 336519.392 4554544.7025 336520.212 4554544.2025 336520.972 4554543.6225 336521.692 4554542.9825 336522.342 4554542.2925 336522.932 4554541.5325 336523.462 4554540.7325 336523.912 4554539.8925 336522.062 4554537.8225 336521.172 4554538.1825 336520.322 4554538.6125 336519.502 4554539.1225 336518.742 4554539.6925 336518.022 4554540.3325 336517.372 4554541.0325 336516.782 4554541.7825 336516.252 4554542.5825 336515.802 4554543.4225 336517.652 4554545.4925</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200025_PI.235">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336077.714 4554862.5765</gml:lowerCorner>
         <gml:upperCorner>336087.384 4554871.2965</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-11-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200025_PI.235</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200025&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200025&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200025_PI.235" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336080.404 4554871.2965 336087.384 4554867.3765 336084.694 4554862.5765 336077.714 4554866.4965 336080.404 4554871.2965</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200028_PI.236">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336121.44 4555325.48</gml:lowerCorner>
         <gml:upperCorner>336134.28 4555331.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200028_PI.236</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200028&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200028&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200028_PI.236" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 336134.18 4555327.43 336133.97 4555327.05 336133.77 4555326.84 336133.53 4555326.67 336133.27 4555326.54 336132.99 4555326.47 336132.44 4555326.48 336132.37 4555325.48 336121.44 4555326.2 336121.62 4555328.93 336121.81 4555331.74 336132.74 4555331.02 336132.65 4555329.6 336133.38 4555329.38 336133.63 4555329.24 336133.95 4555328.94 336134.17 4555328.57 336134.25 4555328.29 336134.28 4555327.85 336134.18 4555327.43</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200035_PI.237">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336275.437 4555215.9055</gml:lowerCorner>
         <gml:upperCorner>336285.127 4555225.9955</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200035_PI.237</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200035&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200035&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200035_PI.237" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336275.437 4555223.3055 336278.397 4555225.9955 336285.127 4555218.5955 336282.157 4555215.9055 336275.437 4555223.3055</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200047_PI.238">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336714.313 4554618.231</gml:lowerCorner>
         <gml:upperCorner>336722.773 4554627.081</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200047_PI.238</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200047&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200047&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200047_PI.238" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336717.403 4554618.231 336714.313 4554620.9415 336719.683 4554627.081 336722.773 4554624.381 336717.403 4554618.231</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200069_PI.239">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336443.28 4555086.67</gml:lowerCorner>
         <gml:upperCorner>336449.49 4555092.01</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200069_PI.239</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200069&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200069&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200069_PI.239" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336448.02 4555092.01 336449.49 4555089.71 336444.75 4555086.67 336443.28 4555088.98 336448.02 4555092.01</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04200075_PI.240">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336420.666 4555036.674</gml:lowerCorner>
         <gml:upperCorner>336427.856 4555045.034</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04200075_PI.240</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04200075&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04200075&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04200075_PI.240" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="43"> 336427.436 4555037.434 336427.256 4555037.284 336426.786 4555037.014 336426.286 4555036.784 336425.906 4555036.674 336425.466 4555036.714 336425.206 4555036.794 336424.696 4555037.044 336424.496 4555037.214 336424.356 4555037.404 336424.276 4555037.604 336424.126 4555039.234 336424.066 4555039.444 336423.846 4555039.834 336423.576 4555040.174 336423.226 4555040.484 336422.116 4555040.944 336421.736 4555041.154 336421.526 4555041.344 336421.206 4555041.844 336420.686 4555042.934 336420.666 4555043.394 336420.706 4555043.734 336420.806 4555043.994 336421.116 4555044.374 336421.546 4555044.684 336422.086 4555044.934 336422.396 4555045.004 336422.716 4555045.034 336423.326 4555045.014 336423.606 4555044.964 336424.126 4555044.774 336424.926 4555044.204 336425.526 4555043.654 336426.096 4555042.984 336426.636 4555042.204 336427.486 4555040.724 336427.726 4555040.124 336427.836 4555039.494 336427.856 4555039.114 336427.826 4555038.364 336427.686 4555037.814 336427.436 4555037.434</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300016_PI.241">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335162.66 4556425.38</gml:lowerCorner>
         <gml:upperCorner>335171.69 4556434.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300016_PI.241</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300016_PI.241" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 335168.37 4556434.66 335171.69 4556430.85 335165.73 4556425.38 335162.66 4556428.73 335166.81 4556432.54 335166.6 4556432.89 335166.51 4556433.12 335166.45 4556433.52 335166.52 4556433.92 335166.62 4556434.14 335166.82 4556434.4 335167.15 4556434.64 335167.45 4556434.75 335167.78 4556434.78 335168.37 4556434.66</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300020_PI.242">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335366.8535 4556240.604</gml:lowerCorner>
         <gml:upperCorner>335375.7235 4556248.364</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300020_PI.242</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300020&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300020&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300020_PI.242" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335373.5035 4556240.604 335366.8535 4556245.034 335369.0735 4556248.364 335375.7235 4556243.924 335373.5035 4556240.604</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300031_PI.243">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335124.42 4555839.535</gml:lowerCorner>
         <gml:upperCorner>335134.84 4555849.145</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300031_PI.243</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300031&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300031&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300031_PI.243" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 335131.17 4555849.145 335134.84 4555845.625 335128.38 4555839.535 335126.33 4555839.535 335125.38 4555839.755 335124.5 4555840.485 335124.42 4555842.315 335124.64 4555843.345 335131.17 4555849.145</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300040_PI.244">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334485.61 4556461.9</gml:lowerCorner>
         <gml:upperCorner>334496.1 4556471.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300040_PI.244</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300040&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300040&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300040_PI.244" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="32"> 334494.24 4556461.96 334493.52 4556461.9 334492.74 4556462.07 334491.88 4556462.72 334491.01 4556464.05 334490.28 4556464.88 334489.45 4556465.58 334488.66 4556466.17 334487.78 4556467.05 334486.98 4556467.93 334485.75 4556469.51 334485.61 4556470.01 334485.66 4556470.49 334485.76 4556470.72 334485.94 4556470.98 334486.12 4556471.14 334486.33 4556471.27 334486.72 4556471.39 334486.88 4556471.4 334487.12 4556471.38 334487.36 4556471.31 334487.57 4556471.2 334487.76 4556471.05 334488.19 4556470.56 334488.74 4556470.94 334490.24 4556471.98 334496.05 4556464.04 334496.1 4556463.77 334495.9 4556463.02 334495.29 4556462.34 334494.56 4556461.99 334494.24 4556461.96</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300049_PI.245">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334660.74 4556727.58</gml:lowerCorner>
         <gml:upperCorner>334668.96 4556737.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300049_PI.245</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300049_PI.245" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="32"> 334668.64 4556729.94 334667.84 4556729.43 334667.94 4556729.14 334667.93 4556728.76 334667.82 4556728.47 334667.71 4556728.32 334667.52 4556728.15 334667.17 4556728 334666.86 4556727.98 334666.67 4556728.02 334666.44 4556728.12 334666.16 4556728.37 334664.94 4556727.58 334660.96 4556733.81 334660.82 4556734.2 334660.76 4556734.49 334660.74 4556734.8 334660.78 4556735.25 334660.91 4556735.69 334661.12 4556736.1 334661.4 4556736.46 334661.74 4556736.76 334662.14 4556736.99 334662.57 4556737.14 334662.87 4556737.19 334663.32 4556737.2 334663.92 4556737.08 334664.2 4556736.96 334664.71 4556736.63 334665 4556736.33 334668.96 4556730.14 334668.64 4556729.94</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300058_PI.246">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334703.415 4556565.9295</gml:lowerCorner>
         <gml:upperCorner>334713.705 4556574.4495</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300058_PI.246</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300058&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300058&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300058_PI.246" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334703.415 4556570.3895 334711.445 4556574.4495 334713.705 4556569.9895 334705.6745 4556565.9295 334703.415 4556570.3895</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300076_PI.247">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334897.222 4556166.0675</gml:lowerCorner>
         <gml:upperCorner>334908.182 4556176.1475</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300076_PI.247</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300076&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300076&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300076_PI.247" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334908.182 4556172.2075 334900.292 4556166.0675 334897.222 4556170.0075 334905.112 4556176.1475 334908.182 4556172.2075</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300107_PI.248">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334829.6045 4556564.4665</gml:lowerCorner>
         <gml:upperCorner>334836.6055 4556571.972</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300107_PI.248</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300107&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300107&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300107_PI.248" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 334832.0995 4556565.303 334829.6045 4556569.671 334833.398 4556571.838 334833.633 4556571.972 334835.675 4556568.5785 334836.6055 4556566.768 334832.577 4556564.4665 334832.0995 4556565.303</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300108_PI.249">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334834.515 4556569.8585</gml:lowerCorner>
         <gml:upperCorner>334839.535 4556574.8785</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300108_PI.249</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300108&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300108&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300108_PI.249" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334839.535 4556571.4185 334836.075 4556569.8585 334834.515 4556573.3185 334837.975 4556574.8785 334839.535 4556571.4185</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300114_PI.250">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>334975.4025 4556236.857</gml:lowerCorner>
         <gml:upperCorner>334984.3425 4556244.117</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-10-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300114_PI.250</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300114&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300114&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300114_PI.250" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 334982.4825 4556244.117 334984.3425 4556240.567 334977.2625 4556236.857 334975.4025 4556240.397 334982.4825 4556244.117</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04300115_PI.251">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335060.7115 4556033.416</gml:lowerCorner>
         <gml:upperCorner>335068.6915 4556042.076</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04300115_PI.251</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04300115&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04300115&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04300115_PI.251" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335060.7115 4556039.676 335063.7615 4556042.076 335068.6915 4556035.816 335065.641 4556033.416 335060.7115 4556039.676</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04400011_PI.252">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335367.943 4557505.586</gml:lowerCorner>
         <gml:upperCorner>335381.553 4557518.476</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04400011_PI.252</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04400011&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04400011&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04400011_PI.252" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335381.553 4557514.256 335371.633 4557505.586 335367.943 4557509.806 335377.863 4557518.476 335381.553 4557514.256</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04400013_PI.253">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335401.02 4557466.48</gml:lowerCorner>
         <gml:upperCorner>335408.3 4557473.94</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04400013_PI.253</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04400013&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04400013&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04400013_PI.253" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335404.15 4557466.48 335401.02 4557471.16 335405.16 4557473.94 335408.3 4557469.26 335404.15 4557466.48</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04400014_PI.254">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335424.002 4557364.9255</gml:lowerCorner>
         <gml:upperCorner>335433.022 4557379.0055</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-02-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04400014_PI.254</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04400014&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04400014&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04400014_PI.254" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 335433.022 4557366.4055 335427.212 4557364.9255 335424.002 4557377.5255 335429.812 4557379.0055 335433.022 4557366.4055</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04400034_PI.255">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335400.47 4557169.72</gml:lowerCorner>
         <gml:upperCorner>335409.54 4557179.14</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04400034_PI.255</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04400034&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04400034&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04400034_PI.255" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 335409.54 4557171.76 335403.12 4557169.72 335400.47 4557178.06 335403.9 4557179.14 335404.98 4557175.75 335407.99 4557176.7 335409.54 4557171.76</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04400088_PI.256">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>335055.303 4557595.8685</gml:lowerCorner>
         <gml:upperCorner>335066.503 4557606.5785</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04400088_PI.256</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04400088&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04400088&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04400088_PI.256" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 335055.303 4557604.0485 335059.893 4557606.5785 335063.033 4557600.8685 335065.183 4557602.0585 335066.503 4557599.6485 335059.643 4557595.8685 335055.303 4557604.0485</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04600036_PI.257">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336205.767 4557876.3645</gml:lowerCorner>
         <gml:upperCorner>336213.1375 4557886.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04600036_PI.257</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04600036&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04600036&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04600036_PI.257" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 336212.95 4557878.33 336213.1375 4557877.792 336208.695 4557876.3645 336205.767 4557885.476 336210.23 4557886.91 336212.95 4557878.33</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04900017_PI.258">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337383.9 4555167.01</gml:lowerCorner>
         <gml:upperCorner>337391.44 4555174.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04900017_PI.258</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04900017&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04900017&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04900017_PI.258" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 337391.44 4555168.65 337388.65 4555167.01 337385.88 4555171.76 337384.9 4555171.21 337384.64 4555171.16 337384.39 4555171.2 337384.16 4555171.33 337383.99 4555171.54 337383.94 4555171.65 337383.9 4555171.77 337383.9 4555172.03 337383.99 4555172.28 337384.06 4555172.39 337384.27 4555172.56 337387.93 4555174.69 337391.44 4555168.65</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A04900049_PI.259">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337172.6595 4555354.219</gml:lowerCorner>
         <gml:upperCorner>337184.6995 4555365.009</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-05-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A04900049_PI.259</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A04900049&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A04900049&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A04900049_PI.259" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10"> 337175.8195 4555354.219 337172.6595 4555358.989 337181.6895 4555365.009 337182.4395 4555363.869 337183.7395 4555364.129 337184.4795 4555363.319 337184.6195 4555362.659 337184.1795 4555361.489 337184.6995 4555360.239 337175.8195 4555354.219</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A05000016_PI.260">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337122.88 4554661.87</gml:lowerCorner>
         <gml:upperCorner>337128.42 4554670.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A05000016_PI.260</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A05000016&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A05000016&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A05000016_PI.260" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337126.64 4554670.64 337128.42 4554662.72 337124.65 4554661.87 337122.88 4554669.8 337126.64 4554670.64</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.43131A05000018_PI.261">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336922.69 4554546.04</gml:lowerCorner>
         <gml:upperCorner>336930.69 4554554.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>43131A05000018_PI.261</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=43131A05000018&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=43131A05000018&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.43131A05000018_PI.261" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336930.69 4554546.59 336923.26 4554546.04 336922.69 4554553.63 336930.12 4554554.19 336930.69 4554546.59</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6158431CF3565G_PI.262">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336150.16 4555848.54</gml:lowerCorner>
         <gml:upperCorner>336155.48 4555853.5</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6158431CF3565G_PI.262</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6158431CF3565G&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6158431CF3565G&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6158431CF3565G_PI.262" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336155.48 4555849.16 336150.73 4555848.54 336150.16 4555852.88 336154.91 4555853.5 336155.48 4555849.16</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6158443CF3565G_PI.263">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336201.7 4555647.4</gml:lowerCorner>
         <gml:upperCorner>336212.74 4555657.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6158443CF3565G_PI.263</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6158443CF3565G&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6158443CF3565G&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6158443CF3565G_PI.263" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22"> 336212.74 4555651.32 336209.39 4555647.4 336201.73 4555653.97 336202.29 4555654.63 336202 4555654.95 336201.85 4555655.21 336201.75 4555655.48 336201.7 4555655.77 336201.71 4555656.06 336201.76 4555656.35 336201.86 4555656.62 336202.01 4555656.87 336202.2 4555657.1 336202.42 4555657.28 336202.68 4555657.43 336202.95 4555657.52 336203.24 4555657.57 336203.68 4555657.55 336204.09 4555657.41 336204.46 4555657.17 336205.08 4555657.88 336212.74 4555651.32</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6261611CF3566A_PI.264">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336064.07 4555955.43</gml:lowerCorner>
         <gml:upperCorner>336071.7 4555962.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6261611CF3566A_PI.264</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6261611CF3566A&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6261611CF3566A&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6261611CF3566A_PI.264" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336071.7 4555957.65 336068.62 4555955.43 336066.05 4555959.01 336065.24 4555958.42 336064.07 4555960.05 336067.97 4555962.85 336071.7 4555957.65</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6263749CF3566C_PI.265">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336244.2 4556018.03</gml:lowerCorner>
         <gml:upperCorner>336254.9 4556028.8</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6263749CF3566C_PI.265</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6263749CF3566C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6263749CF3566C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6263749CF3566C_PI.265" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="75"> 336252.19 4556027.88 336252.61 4556027.59 336253 4556027.26 336253.36 4556026.9 336253.68 4556026.51 336254.23 4556025.65 336254.44 4556025.19 336254.9 4556023.93 336254.88 4556023.34 336254.72 4556022.89 336254.64 4556022.75 336254.45 4556022.5 336254.23 4556022.28 336253.82 4556022.03 336253.52 4556021.93 336253.21 4556021.88 336252.73 4556021.91 336252.28 4556022.06 336252.01 4556022.22 336251.77 4556022.43 336251.16 4556023.61 336250.85 4556023.95 336250.44 4556024.16 336250.09 4556024.21 336249.75 4556024.18 336249.43 4556024.06 336249.14 4556023.86 336248.92 4556023.59 336248.78 4556023.28 336248.72 4556022.94 336248.75 4556022.51 336248.84 4556022.13 336248.99 4556021.78 336249.21 4556021.46 336249.47 4556020.98 336249.63 4556020.51 336249.62 4556020.02 336249.54 4556019.53 336249.26 4556018.84 336248.96 4556018.55 336248.62 4556018.32 336248.24 4556018.16 336247.84 4556018.06 336247.42 4556018.03 336247.01 4556018.07 336246.62 4556018.19 336246.24 4556018.37 336245.76 4556018.75 336245.39 4556019.25 336245.08 4556019.78 336244.8 4556020.34 336244.58 4556020.92 336244.41 4556021.51 336244.29 4556022.12 336244.22 4556022.74 336244.2 4556023.36 336244.24 4556023.98 336244.33 4556024.59 336244.48 4556025.19 336244.67 4556025.78 336244.92 4556026.35 336245.21 4556026.9 336245.78 4556027.57 336246.46 4556028.13 336246.83 4556028.37 336247.31 4556028.54 336247.8 4556028.67 336248.3 4556028.76 336249.32 4556028.8 336249.83 4556028.75 336250.33 4556028.66 336250.82 4556028.53 336251.29 4556028.35 336251.75 4556028.14 336252.19 4556027.88</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6265507CF3566E_PI.266">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336153.7355 4556345.928</gml:lowerCorner>
         <gml:upperCorner>336158.9155 4556352.578</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265507CF3566E_PI.266</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265507CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265507CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6265507CF3566E_PI.266" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336158.9155 4556346.988 336155.4555 4556345.928 336153.7355 4556351.518 336157.1955 4556352.578 336158.9155 4556346.988</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6265507CF3566E_PI.267">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336163.8455 4556325.598</gml:lowerCorner>
         <gml:upperCorner>336182.945 4556352.688</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265507CF3566E_PI.267</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265507CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265507CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6265507CF3566E_PI.267" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336182.945 4556329.258 336171.075 4556325.598 336163.8455 4556349.028 336175.7155 4556352.688 336182.945 4556329.258</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6265510CF3566E_PI.268">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336116.066 4556464.4685</gml:lowerCorner>
         <gml:upperCorner>336129.086 4556476.5385</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2006-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265510CF3566E_PI.268</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265510CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265510CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6265510CF3566E_PI.268" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336129.086 4556472.1385 336119.636 4556464.4685 336116.066 4556468.8685 336125.5165 4556476.5385 336129.086 4556472.1385</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6366806CF3566E_PI.269">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336273.74 4556402.28</gml:lowerCorner>
         <gml:upperCorner>336280.15 4556409.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6366806CF3566E_PI.269</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6366806CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6366806CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6366806CF3566E_PI.269" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336277.15 4556409.58 336280.15 4556405.26 336275.85 4556402.28 336273.74 4556405.32 336277.27 4556407.77 336276.38 4556409.04 336277.15 4556409.58</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6366808CF3566E_PI.270">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336251.186 4556433.1875</gml:lowerCorner>
         <gml:upperCorner>336258.776 4556441.4475</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6366808CF3566E_PI.270</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6366808CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6366808CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6366808CF3566E_PI.270" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336251.186 4556439.1275 336254.196 4556441.4475 336258.776 4556435.5075 336255.766 4556433.1875 336251.186 4556439.1275</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6366813CF3566E_PI.271">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336261.636 4556413.3775</gml:lowerCorner>
         <gml:upperCorner>336270.176 4556423.0075</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6366813CF3566E_PI.271</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6366813CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6366813CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6366813CF3566E_PI.271" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336266.946 4556413.3775 336261.636 4556420.6475 336264.866 4556423.0075 336270.176 4556415.7375 336266.946 4556413.3775</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6454601CF3565D_PI.272">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336461.94 4555240.4</gml:lowerCorner>
         <gml:upperCorner>336470.62 4555245.7</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6454601CF3565D_PI.272</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6454601CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6454601CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6454601CF3565D_PI.272" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="69"> 336461.96 4555241.1 336461.94 4555241.25 336461.98 4555241.56 336462.16 4555241.77 336462.38 4555241.94 336462.57 4555242.14 336462.78 4555242.5 336462.87 4555242.77 336462.91 4555243.05 336462.9 4555243.33 336462.84 4555243.6 336462.66 4555243.98 336462.58 4555244.23 336462.65 4555244.63 336462.82 4555245 336463.08 4555245.3 336463.41 4555245.54 336463.66 4555245.64 336463.93 4555245.7 336464.33 4555245.7 336464.59 4555245.64 336464.84 4555245.54 336465.07 4555245.39 336465.27 4555245.21 336465.57 4555244.85 336465.89 4555244.6 336466.25 4555244.4 336466.84 4555244.24 336467.45 4555244.24 336467.85 4555244.33 336468.37 4555244.54 336468.67 4555244.6 336468.98 4555244.6 336469.43 4555244.5 336469.84 4555244.3 336470.18 4555243.99 336470.44 4555243.61 336470.59 4555243.17 336470.62 4555242.87 336470.6 4555242.56 336470.53 4555242.26 336470.33 4555241.85 336470.14 4555241.61 336469.91 4555241.4 336469.65 4555241.24 336469.22 4555241.09 336468.91 4555241.05 336468.61 4555241.06 336468.16 4555241.18 336468.02 4555241.25 336467.86 4555241.42 336467.48 4555241.72 336467.06 4555241.95 336466.6 4555242.1 336466.12 4555242.17 336465.64 4555242.16 336465.4 4555242.12 336464.94 4555241.98 336464.72 4555241.88 336464.31 4555241.63 336463.95 4555241.3 336463.43 4555240.61 336463.16 4555240.45 336463.01 4555240.41 336462.71 4555240.4 336462.41 4555240.5 336462.17 4555240.69 336462.08 4555240.81 336461.96 4555241.1</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6454607CF3565D_PI.273">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336359.96 4555272.42</gml:lowerCorner>
         <gml:upperCorner>336367.98 4555278.42</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6454607CF3565D_PI.273</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6454607CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6454607CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6454607CF3565D_PI.273" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336360 4555278.36 336361.07 4555278.42 336362.02 4555276.57 336367.94 4555276.49 336367.98 4555272.42 336359.96 4555272.45 336360 4555278.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6454608CF3565D_PI.274">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336371.09 4555290.96</gml:lowerCorner>
         <gml:upperCorner>336374.95 4555297.89</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6454608CF3565D_PI.274</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6454608CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6454608CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6454608CF3565D_PI.274" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336371.09 4555291.15 336371.45 4555297.89 336374.95 4555297.71 336374.59 4555290.96 336371.09 4555291.15</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6454609CF3565D_PI.275">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336397.75 4555309.16</gml:lowerCorner>
         <gml:upperCorner>336405.19 4555313.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6454609CF3565D_PI.275</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6454609CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6454609CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6454609CF3565D_PI.275" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336397.75 4555313.87 336398.5 4555313.87 336399 4555312.51 336405.19 4555312.51 336405.19 4555309.16 336397.75 4555309.16 336397.75 4555313.87</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6454610CF3565D_PI.276">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336356.77 4555303.18</gml:lowerCorner>
         <gml:upperCorner>336363.92 4555307.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6454610CF3565D_PI.276</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6454610CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6454610CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6454610CF3565D_PI.276" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336363.92 4555303.19 336356.78 4555303.18 336356.77 4555307.18 336363.91 4555307.19 336363.92 4555303.19</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6455402CF3565E_PI.277">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336348.32 4555371.99</gml:lowerCorner>
         <gml:upperCorner>336354.66 4555376.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6455402CF3565E_PI.277</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6455402CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6455402CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6455402CF3565E_PI.277" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336354.66 4555375.54 336353.81 4555371.99 336348.32 4555373.3 336349.17 4555376.85 336354.66 4555375.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6455403CF3565E_PI.278">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336357.23 4555370.28</gml:lowerCorner>
         <gml:upperCorner>336363.59 4555374.17</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6455403CF3565E_PI.278</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6455403CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6455403CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6455403CF3565E_PI.278" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336363.53 4555374.17 336363.59 4555370.38 336357.29 4555370.28 336357.23 4555374.07 336363.53 4555374.17</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6455404CF3565E_PI.279">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336390.65 4555346.73</gml:lowerCorner>
         <gml:upperCorner>336399.78 4555352.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6455404CF3565E_PI.279</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6455404CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6455404CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6455404CF3565E_PI.279" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 336399.78 4555350.82 336398.76 4555346.73 336391.35 4555348.58 336391.53 4555349.29 336391.16 4555349.49 336390.92 4555349.72 336390.74 4555350.03 336390.65 4555350.4 336390.66 4555350.72 336390.75 4555351.02 336390.87 4555351.24 336391.03 4555351.44 336391.28 4555351.63 336391.57 4555351.76 336391.82 4555351.81 336392.15 4555351.79 336392.37 4555352.67 336399.78 4555350.82</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6455408CF3565E_PI.280">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336328.58 4555385.76</gml:lowerCorner>
         <gml:upperCorner>336334.18 4555395.31</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6455408CF3565E_PI.280</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6455408CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6455408CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6455408CF3565E_PI.280" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="36"> 336332.31 4555395.23 336332.99 4555394.91 336333.7 4555393.98 336334.13 4555392.78 336334.18 4555391.35 336334.16 4555390.63 336334.03 4555389.21 336333.92 4555388.5 336333.72 4555387.58 336333.55 4555387.17 336333.16 4555386.61 336332.65 4555386.18 336332.46 4555386.06 336332.04 4555385.89 336331.38 4555385.76 336330.93 4555385.77 336330.49 4555385.86 336329.88 4555386.13 336329.51 4555386.4 336329.2 4555386.72 336328.95 4555387.09 336328.76 4555387.5 336328.65 4555387.93 336328.58 4555388.51 336328.76 4555389.21 336329.01 4555389.89 336329.31 4555390.54 336329.67 4555391.16 336329.78 4555391.63 336329.85 4555392.11 336329.88 4555392.6 336329.86 4555393.08 336330.06 4555394.07 336330.73 4555394.92 336331.54 4555395.31 336332.31 4555395.23</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6457109CF3565G_PI.281">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336362.11 4555552.49</gml:lowerCorner>
         <gml:upperCorner>336370.53 4555556.92</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6457109CF3565G_PI.281</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6457109CF3565G&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6457109CF3565G&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6457109CF3565G_PI.281" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="45"> 336370.53 4555555 336370.48 4555554.49 336370.3 4555554.01 336370.12 4555553.73 336369.58 4555553.32 336369.12 4555553.07 336368.65 4555552.87 336368.16 4555552.71 336367.16 4555552.52 336366.64 4555552.49 336365.62 4555552.57 336365.12 4555552.67 336364.07 4555553.01 336363.36 4555553.34 336362.73 4555553.7 336362.45 4555553.97 336362.22 4555554.36 336362.15 4555554.58 336362.11 4555554.89 336362.13 4555555.19 336362.21 4555555.49 336362.43 4555555.89 336362.76 4555556.21 336363.17 4555556.42 336363.39 4555556.48 336363.78 4555556.5 336364.15 4555556.43 336364.78 4555556.2 336365.28 4555556.1 336366.13 4555556.1 336366.64 4555556.2 336366.96 4555556.31 336367.27 4555556.45 336367.7 4555556.73 336367.86 4555556.79 336368.18 4555556.88 336368.52 4555556.92 336369.03 4555556.86 336369.35 4555556.75 336369.65 4555556.58 336369.92 4555556.37 336370.14 4555556.11 336370.32 4555555.82 336370.49 4555555.34 336370.53 4555555</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6457801CF3565G_PI.282">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336312.14 4555551.4</gml:lowerCorner>
         <gml:upperCorner>336319.1 4555557.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6457801CF3565G_PI.282</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6457801CF3565G&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6457801CF3565G&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6457801CF3565G_PI.282" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336313.96 4555557.61 336319.1 4555553.97 336317.29 4555551.4 336312.14 4555555.04 336313.96 4555557.61</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6457808CF3565E_PI.283">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336333.729 4555495.83</gml:lowerCorner>
         <gml:upperCorner>336338.54 4555506.3455</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6457808CF3565E_PI.283</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6457808CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6457808CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6457808CF3565E_PI.283" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336338.109 4555506.3455 336338.46 4555504.66 336338.54 4555502.65 336338.35 4555500.39 336337.96 4555498.66 336337.44 4555497.42 336336.43 4555495.83 336333.729 4555497.0655 336338.109 4555506.3455</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6457809CF3565E_PI.284">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336331.06 4555497.0655</gml:lowerCorner>
         <gml:upperCorner>336338.109 4555506.3455</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6457809CF3565E_PI.284</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6457809CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6457809CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6457809CF3565E_PI.284" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336333.729 4555497.0655 336331.06 4555498.37 336331.65 4555500.16 336332.27 4555501.35 336333.36 4555502.75 336334.98 4555504.33 336336.58 4555505.55 336338.109 4555506.3455 336333.729 4555497.0655</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6457811CF3565E_PI.285">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336363.38 4555521.75</gml:lowerCorner>
         <gml:upperCorner>336369.3 4555529.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-08-20T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6457811CF3565E_PI.285</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6457811CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6457811CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6457811CF3565E_PI.285" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23"> 336369.11 4555528.94 336369.3 4555528.33 336369.19 4555527.61 336368.75 4555526.88 336367.79 4555526.05 336367.16 4555525.37 336366.53 4555524.52 336366.06 4555523.32 336365.78 4555522.21 336365.46 4555521.92 336364.87 4555521.75 336364.32 4555521.87 336363.89 4555522.12 336363.53 4555523.02 336363.38 4555524.28 336363.42 4555525.1 336363.7 4555526.08 336364.85 4555527.82 336365.86 4555529.01 336366.69 4555529.47 336367.43 4555529.56 336368.42 4555529.37 336369.11 4555528.94</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6465210CF3566E_PI.286">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336276.6325 4556339.0015</gml:lowerCorner>
         <gml:upperCorner>336284.98 4556346.1265</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465210CF3566E_PI.286</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465210CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465210CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6465210CF3566E_PI.286" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336276.6325 4556342.2485 336283.0035 4556346.1265 336284.98 4556342.8795 336278.609 4556339.0015 336276.6325 4556342.2485</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6466201CF3566E_PI.287">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336354.31 4556416.02</gml:lowerCorner>
         <gml:upperCorner>336361.76 4556424.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466201CF3566E_PI.287</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466201CF3566E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466201CF3566E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6466201CF3566E_PI.287" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11"> 336354.31 4556423.05 336355.98 4556424.1 336357.81 4556421.18 336360.64 4556420.47 336361.21 4556420.15 336361.55 4556419.67 336361.76 4556419.05 336361.73 4556418.45 336361.52 4556417.77 336358.85 4556416.02 336354.31 4556423.05</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6555803CF3565F_PI.288">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336443.28 4555364.37</gml:lowerCorner>
         <gml:upperCorner>336446.29 4555370.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6555803CF3565F_PI.288</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6555803CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6555803CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6555803CF3565F_PI.288" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336443.28 4555364.37 336443.29 4555370.37 336446.29 4555370.37 336446.28 4555364.37 336443.28 4555364.37</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6555806CF3565F_PI.289">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336451.33 4555290.85</gml:lowerCorner>
         <gml:upperCorner>336457.47 4555299.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6555806CF3565F_PI.289</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6555806CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6555806CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6555806CF3565F_PI.289" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336451.34 4555299.95 336456.04 4555299.94 336456.03 4555293.09 336457.47 4555293.09 336457.47 4555290.85 336451.33 4555290.85 336451.34 4555299.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6555807CF3565F_PI.290">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336451.39 4555310.31</gml:lowerCorner>
         <gml:upperCorner>336456.86 4555319.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6555807CF3565F_PI.290</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6555807CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6555807CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6555807CF3565F_PI.290" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 336451.39 4555319.62 336455.55 4555319.67 336455.61 4555312.63 336456.08 4555312.52 336456.58 4555312.26 336456.78 4555311.84 336456.86 4555311.48 336456.83 4555311.08 336456.64 4555310.66 336456.18 4555310.34 336455.62 4555310.31 336455.15 4555310.46 336454.73 4555310.69 336454.54 4555311.1 336454.54 4555311.49 336451.56 4555311.55 336451.39 4555319.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6555808CF3565F_PI.291">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336451.297 4555329.464</gml:lowerCorner>
         <gml:upperCorner>336455.4545 4555338.089</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6555808CF3565F_PI.291</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6555808CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6555808CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6555808CF3565F_PI.291" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336455.4545 4555338.089 336455.3565 4555330.503 336454.415 4555330.503 336454.415 4555329.464 336452.3365 4555329.464 336452.3365 4555330.503 336451.297 4555330.503 336451.297 4555338.089 336455.4545 4555338.089</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6556902CF3565F_PI.292">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336441.24 4555471.84</gml:lowerCorner>
         <gml:upperCorner>336446.22 4555476.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6556902CF3565F_PI.292</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6556902CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6556902CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6556902CF3565F_PI.292" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336441.24 4555474.95 336442.97 4555476.75 336446.22 4555473.64 336444.5 4555471.84 336441.24 4555474.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6556904CF3565E_PI.293">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336422.67 4555440.09</gml:lowerCorner>
         <gml:upperCorner>336431.16 4555446.83</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6556904CF3565E_PI.293</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6556904CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6556904CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6556904CF3565E_PI.293" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336422.67 4555443.74 336424.32 4555446.83 336431.16 4555443.17 336429.51 4555440.09 336422.67 4555443.74</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6556906CF3565E_PI.294">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336382.9055 4555411.67</gml:lowerCorner>
         <gml:upperCorner>336393.481 4555419.2505</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-11-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6556906CF3565E_PI.294</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6556906CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6556906CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6556906CF3565E_PI.294" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="52"> 336386.1095 4555418.4875 336386.3725 4555418.1375 336386.4145 4555418.1065 336386.7735 4555417.961 336387.209 4555418.0035 336387.406 4555418.1065 336387.897 4555418.275 336388.5505 4555418.335 336389.037 4555418.3325 336390.167 4555418.169 336391.1115 4555417.8535 336391.22 4555417.801 336391.963 4555417.3365 336392.679 4555416.6445 336393.051 4555416.1235 336393.1515 4555415.934 336393.425 4555415.126 336393.481 4555414.2745 336393.316 4555413.4375 336393.2035 4555413.1485 336392.987 4555412.772 336392.4755 4555412.2335 336391.8285 4555411.869 336391.525 4555411.776 336390.935 4555411.67 336390.02 4555411.6915 336389.1365 4555411.932 336388.337 4555412.3775 336387.668 4555413.002 336387.2535 4555413.6065 336387 4555414.1425 336386.6425 4555414.497 336386.5675 4555414.548 336386.016 4555414.766 336385.423 4555414.767 336385.3465 4555414.7505 336384.8545 4555414.743 336384.32 4555414.9375 336383.9005 4555415.322 336383.745 4555415.5895 336383.1065 4555416.6855 336382.9055 4555418.03 336383.211 4555418.564 336383.2305 4555418.588 336383.725 4555419.003 336384.331 4555419.2265 336384.5075 4555419.2505 336384.974 4555419.232 336385.423 4555419.098 336385.5385 4555419.038 336385.993 4555418.6515 336386.1095 4555418.4875</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6556909CF3565F_PI.295">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336441.709 4555436.1045</gml:lowerCorner>
         <gml:upperCorner>336450.689 4555442.3645</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6556909CF3565F_PI.295</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6556909CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6556909CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6556909CF3565F_PI.295" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="42"> 336441.949 4555437.8745 336441.759 4555438.4045 336441.709 4555438.7845 336441.729 4555439.1645 336441.809 4555439.5345 336441.959 4555439.8845 336442.289 4555440.3445 336442.569 4555440.5945 336442.899 4555440.7945 336443.249 4555440.9345 336444.129 4555440.9245 336445.389 4555440.5745 336445.969 4555440.4945 336446.519 4555440.5345 336447.059 4555440.7145 336447.579 4555440.9945 336449.009 4555442.0345 336449.439 4555442.2745 336449.829 4555442.3645 336450.169 4555442.3045 336450.429 4555442.0745 336450.579 4555441.6845 336450.659 4555441.1245 336450.689 4555440.4345 336450.659 4555438.8145 336450.569 4555438.1045 336450.429 4555437.6045 336450.219 4555437.2545 336449.939 4555436.9945 336449.599 4555436.7645 336449.139 4555436.5645 336448.519 4555436.3745 336447.729 4555436.2045 336446.809 4555436.1045 336445.869 4555436.1045 336444.979 4555436.2445 336444.179 4555436.4645 336443.499 4555436.7045 336442.959 4555436.9345 336442.549 4555437.1445 336442.249 4555437.3645 336441.949 4555437.8745</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6558614CF3565H_PI.296">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336563.72 4555655.6</gml:lowerCorner>
         <gml:upperCorner>336571.38 4555661.13</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6558614CF3565H_PI.296</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6558614CF3565H&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6558614CF3565H&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6558614CF3565H_PI.296" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336564.71 4555655.6 336563.72 4555659.37 336570.39 4555661.13 336571.38 4555657.35 336564.71 4555655.6</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6558615CF3565H_PI.297">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336551.14 4555654.29</gml:lowerCorner>
         <gml:upperCorner>336558.06 4555659.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6558615CF3565H_PI.297</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6558615CF3565H&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6558615CF3565H&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6558615CF3565H_PI.297" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 336551.14 4555655.49 336551.29 4555655.97 336552.07 4555657.08 336553.05 4555657.68 336554.29 4555658.23 336555.59 4555658.86 336556.29 4555659.36 336557 4555659.37 336557.48 4555658.98 336558.06 4555657.57 336558.04 4555656.39 336557.59 4555655.56 336557.04 4555654.87 336555.56 4555654.42 336554.06 4555654.29 336552.09 4555654.75 336551.39 4555655.15 336551.14 4555655.49</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6558681CF3565H_PI.298">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336527.51 4555780.64</gml:lowerCorner>
         <gml:upperCorner>336535.15 4555787.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-04-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6558681CF3565H_PI.298</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6558681CF3565H&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6558681CF3565H&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6558681CF3565H_PI.298" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336528.69 4555780.64 336527.51 4555784.51 336533.47 4555787.28 336535.15 4555783.65 336528.69 4555780.64</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6560225CF3566A_PI.299">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336388.92 4555795.96</gml:lowerCorner>
         <gml:upperCorner>336395.65 4555807.51</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-02-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6560225CF3566A_PI.299</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6560225CF3566A&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6560225CF3566A&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6560225CF3566A_PI.299" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 336395.65 4555797 336391.68 4555795.96 336388.92 4555806.47 336389.5 4555806.62 336389.75 4555806.87 336390.16 4555807.15 336390.73 4555807.38 336391.1 4555807.45 336391.47 4555807.46 336391.84 4555807.42 336392.19 4555807.33 336392.89 4555807.51 336395.65 4555797</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6563103CF3566D_PI.300">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336427.544 4556143.446</gml:lowerCorner>
         <gml:upperCorner>336435.054 4556148.416</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2008-03-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6563103CF3566D_PI.300</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6563103CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6563103CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6563103CF3566D_PI.300" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336434.474 4556143.446 336427.544 4556144.466 336428.124 4556148.416 336435.054 4556147.406 336434.474 4556143.446</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6567824CF3566F_PI.301">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336465.68 4556461.44</gml:lowerCorner>
         <gml:upperCorner>336474.45 4556468.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6567824CF3566F_PI.301</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6567824CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6567824CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6567824CF3566F_PI.301" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336474.45 4556464.99 336467.44 4556461.44 336465.68 4556464.92 336472.69 4556468.46 336474.45 4556464.99</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655102CF3565F_PI.302">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336517.56 4555345.39</gml:lowerCorner>
         <gml:upperCorner>336522.34 4555348.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655102CF3565F_PI.302</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655102CF3565F_PI.302" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336522.34 4555345.45 336517.6 4555345.39 336517.56 4555348.4 336522.3 4555348.46 336522.34 4555345.45</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655102CF3565F_PI.303">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336518.92 4555351.31</gml:lowerCorner>
         <gml:upperCorner>336522.22 4555357.63</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655102CF3565F_PI.303</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655102CF3565F_PI.303" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336522.22 4555351.35 336519 4555351.31 336518.92 4555357.59 336522.14 4555357.63 336522.22 4555351.35</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655301CF3565F_PI.304">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336528.8095 4555512.564</gml:lowerCorner>
         <gml:upperCorner>336546.2095 4555519.894</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655301CF3565F_PI.304</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655301CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655301CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655301CF3565F_PI.304" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336546.2095 4555512.854 336528.9295 4555512.564 336528.8095 4555519.604 336546.0895 4555519.894 336546.2095 4555512.854</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655307CF3565F_PI.305">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336525.74 4555450.19</gml:lowerCorner>
         <gml:upperCorner>336532.18 4555454.92</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655307CF3565F_PI.305</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655307CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655307CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655307CF3565F_PI.305" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 336532.03 4555454.61 336532.14 4555454.37 336532.15 4555454.24 336532.18 4555450.23 336525.76 4555450.19 336525.74 4555453.29 336530.68 4555453.32 336530.68 4555454.28 336530.76 4555454.52 336530.91 4555454.73 336531.12 4555454.87 336531.24 4555454.91 336531.49 4555454.92 336531.62 4555454.9 336531.85 4555454.79 336532.03 4555454.61</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655701CF3565F_PI.306">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336585.56 4555356.69</gml:lowerCorner>
         <gml:upperCorner>336590.3 4555368.32</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655701CF3565F_PI.306</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655701CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655701CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655701CF3565F_PI.306" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 336587.43 4555368.26 336587.83 4555368.32 336588.23 4555368.31 336588.63 4555368.24 336589.01 4555368.1 336589.18 4555368 336589.51 4555367.77 336589.8 4555367.48 336590.03 4555367.15 336590.26 4555366.59 336590.3 4555366.39 336590.16 4555356.69 336585.56 4555356.76 336585.7 4555366.46 336585.82 4555366.85 336586 4555367.21 336586.11 4555367.38 336586.38 4555367.68 336586.86 4555368.04 336587.43 4555368.26</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655703CF3565F_PI.307">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336616.307 4555357.852</gml:lowerCorner>
         <gml:upperCorner>336619.968 4555364.557</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-11-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655703CF3565F_PI.307</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655703CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655703CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655703CF3565F_PI.307" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336619.9065 4555364.557 336619.968 4555357.8855 336616.3685 4555357.852 336616.307 4555364.5235 336619.9065 4555364.557</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655704CF3565F_PI.308">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336614.5 4555323.54</gml:lowerCorner>
         <gml:upperCorner>336619.78 4555331.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655704CF3565F_PI.308</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655704CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655704CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655704CF3565F_PI.308" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336619.78 4555331.54 336619.7 4555323.54 336614.5 4555323.59 336614.52 4555325.89 336615.72 4555325.88 336615.78 4555331.58 336619.78 4555331.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6655709CF3565D_PI.309">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336579.92 4555302.84</gml:lowerCorner>
         <gml:upperCorner>336590.17 4555308.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6655709CF3565D_PI.309</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6655709CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6655709CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6655709CF3565D_PI.309" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="55"> 336579.92 4555306.04 336579.95 4555306.23 336580.07 4555306.6 336580.26 4555306.95 336580.49 4555307.26 336580.95 4555307.65 336581.49 4555307.89 336582.28 4555308.02 336582.49 4555308.01 336582.7 4555307.97 336582.89 4555307.89 336583.15 4555307.72 336583.21 4555307.64 336583.93 4555307.39 336584.69 4555307.26 336585.45 4555307.27 336585.83 4555307.32 336586.2 4555307.41 336586.91 4555307.68 336587.01 4555307.82 336587.09 4555308.09 336587.05 4555308.4 336588.43 4555308.33 336588.35 4555308.06 336588.32 4555307.7 336588.39 4555307.34 336588.48 4555307.13 336588.61 4555306.92 336588.78 4555306.74 336588.96 4555306.6 336589.54 4555306.3 336589.83 4555306.01 336589.91 4555305.9 336590.13 4555305.4 336590.17 4555305.12 336590.16 4555304.86 336590.11 4555304.58 336590 4555304.34 336589.78 4555303.99 336589.35 4555303.65 336588.57 4555303.35 336587.76 4555303.12 336586.95 4555302.95 336586.12 4555302.86 336585.29 4555302.84 336584.45 4555302.88 336583.63 4555303 336581.85 4555303.42 336581.39 4555303.6 336580.93 4555303.82 336580.77 4555303.93 336580.35 4555304.35 336580.06 4555304.87 336579.92 4555305.44 336579.92 4555306.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6661916CF3566B_PI.310">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336550.943 4555977.0645</gml:lowerCorner>
         <gml:upperCorner>336559.263 4555984.7545</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6661916CF3566B_PI.310</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6661916CF3566B&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6661916CF3566B&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6661916CF3566B_PI.310" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336550.943 4555980.7645 336556.693 4555984.7545 336559.263 4555981.0545 336553.513 4555977.0645 336550.943 4555980.7645</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6664905CF3566D_PI.311">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336565.596 4556157.0725</gml:lowerCorner>
         <gml:upperCorner>336572.534 4556163.281</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-01-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6664905CF3566D_PI.311</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6664905CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6664905CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6664905CF3566D_PI.311" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336565.596 4556160.0045 336570.6225 4556163.281 336572.534 4556160.349 336567.5075 4556157.0725 336565.596 4556160.0045</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6667202CF3566F_PI.312">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336653.76 4556438.87</gml:lowerCorner>
         <gml:upperCorner>336659.75 4556444.22</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6667202CF3566F_PI.312</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6667202CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6667202CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6667202CF3566F_PI.312" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336658.11 4556444.22 336659.75 4556441.71 336655.39 4556438.87 336653.76 4556441.37 336658.11 4556444.22</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6667212CF3566F_PI.313">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336662.1175 4556442.3855</gml:lowerCorner>
         <gml:upperCorner>336669.621 4556448.719</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-10-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6667212CF3566F_PI.313</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6667212CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6667212CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6667212CF3566F_PI.313" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336662.1175 4556444.9 336667.984 4556448.719 336669.621 4556446.2045 336663.7545 4556442.3855 336662.1175 4556444.9</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6667213CF3566F_PI.314">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336664.44 4556436.44</gml:lowerCorner>
         <gml:upperCorner>336673.47 4556444.03</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6667213CF3566F_PI.314</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6667213CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6667213CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6667213CF3566F_PI.314" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336671.54 4556444.03 336673.47 4556441.07 336666.37 4556436.44 336664.44 4556439.4 336671.54 4556444.03</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6667217CF3566F_PI.315">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336646.82 4556426.18</gml:lowerCorner>
         <gml:upperCorner>336652.61 4556432.84</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-11-09T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6667217CF3566F_PI.315</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6667217CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6667217CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6667217CF3566F_PI.315" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336652.61 4556427.81 336650.09 4556426.18 336646.82 4556431.2 336649.33 4556432.84 336652.61 4556427.81</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6754516CF3565D_PI.316">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336665.2375 4555302.8425</gml:lowerCorner>
         <gml:upperCorner>336675.8375 4555305.9425</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-11-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6754516CF3565D_PI.316</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6754516CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6754516CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6754516CF3565D_PI.316" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336665.2375 4555305.9425 336675.8375 4555305.9425 336675.8375 4555302.8425 336665.2375 4555302.8425 336665.2375 4555305.9425</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6754521CF3565D_PI.317">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336583.395 4555225.559</gml:lowerCorner>
         <gml:upperCorner>336592.411 4555229.0015</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-02-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6754521CF3565D_PI.317</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6754521CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6754521CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6754521CF3565D_PI.317" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336583.395 4555228.9585 336592.3945 4555229.0015 336592.411 4555225.6015 336583.411 4555225.559 336583.395 4555228.9585</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6754524CF3565D_PI.318">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336531.642 4555263.646</gml:lowerCorner>
         <gml:upperCorner>336538.8985 4555267.188</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-06-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6754524CF3565D_PI.318</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6754524CF3565D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6754524CF3565D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6754524CF3565D_PI.318" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336531.6775 4555263.646 336531.642 4555267.146 336538.878 4555267.188 336538.8985 4555263.688 336531.6775 4555263.646</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756208CF3565F_PI.319">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336597.61 4555511.69</gml:lowerCorner>
         <gml:upperCorner>336602.92 4555515.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756208CF3565F_PI.319</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756208CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756208CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756208CF3565F_PI.319" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336597.98 4555511.69 336597.61 4555515.02 336602.55 4555515.58 336602.92 4555512.25 336597.98 4555511.69</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756212CF3565F_PI.320">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336581.84 4555517.99</gml:lowerCorner>
         <gml:upperCorner>336585.63 4555522.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756212CF3565F_PI.320</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756212CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756212CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756212CF3565F_PI.320" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336585.59 4555522.78 336585.63 4555518.03 336581.88 4555517.99 336581.84 4555522.74 336585.59 4555522.78</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756213CF3565F_PI.321">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336581.14 4555510.72</gml:lowerCorner>
         <gml:upperCorner>336586.18 4555514.01</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756213CF3565F_PI.321</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756213CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756213CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756213CF3565F_PI.321" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="36"> 336586.18 4555512.56 336586.14 4555512.33 336586 4555512.02 336585.79 4555511.75 336585.51 4555511.54 336585.08 4555511.4 336583.74 4555511.41 336583.71 4555511.14 336583.59 4555510.94 336583.3 4555510.75 336583.08 4555510.72 336582.84 4555510.77 336582.65 4555510.89 336582.57 4555510.98 336582.46 4555511.18 336582.45 4555511.43 336582.22 4555511.44 336581.99 4555511.5 336581.78 4555511.59 336581.51 4555511.81 336581.3 4555512.08 336581.17 4555512.4 336581.14 4555512.85 336581.22 4555513.19 336581.38 4555513.49 336581.53 4555513.66 336581.71 4555513.8 336582.13 4555513.99 336582.24 4555514.01 336585.23 4555513.96 336585.55 4555513.82 336585.74 4555513.69 336585.9 4555513.51 336586.02 4555513.33 336586.15 4555513.01 336586.18 4555512.56</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756218CF3565F_PI.322">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336627.99 4555515.63</gml:lowerCorner>
         <gml:upperCorner>336635.42 4555519.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-04-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756218CF3565F_PI.322</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756218CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756218CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756218CF3565F_PI.322" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 336635.36 4555518.19 336635.41 4555517.99 336635.42 4555517.68 336635.31 4555517.29 336635.15 4555517.04 336634.93 4555516.84 336634.65 4555516.69 336634.46 4555516.64 336633.82 4555516.6 336633.86 4555516.1 336628.27 4555515.63 336627.99 4555518.93 336633.59 4555519.4 336633.63 4555518.9 336634.26 4555518.96 336634.66 4555518.89 336635.01 4555518.69 336635.16 4555518.54 336635.36 4555518.19</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756219CF3565F_PI.323">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336613.15 4555512.26</gml:lowerCorner>
         <gml:upperCorner>336617.42 4555517.51</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756219CF3565F_PI.323</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756219CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756219CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756219CF3565F_PI.323" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336616.57 4555517.51 336617.42 4555512.89 336614 4555512.26 336613.15 4555516.88 336616.57 4555517.51</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756220CF3565F_PI.324">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336606.15 4555508.9</gml:lowerCorner>
         <gml:upperCorner>336610.76 4555516.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756220CF3565F_PI.324</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756220CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756220CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756220CF3565F_PI.324" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336610.76 4555509.44 336607.21 4555508.9 336606.15 4555515.82 336609.71 4555516.36 336610.76 4555509.44</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6756221CF3565E_PI.325">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336641.7045 4555494.425</gml:lowerCorner>
         <gml:upperCorner>336647.767 4555501.3435</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-07-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6756221CF3565E_PI.325</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6756221CF3565E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6756221CF3565E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6756221CF3565E_PI.325" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336647.767 4555495.587 336646.289 4555495.3325 336646.34 4555495.037 336642.792 4555494.425 336641.7045 4555500.732 336645.2525 4555501.3435 336645.847 4555497.8945 336647.3255 4555498.1495 336647.767 4555495.587</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757101CF3565F_PI.326">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336654.32 4555462.2</gml:lowerCorner>
         <gml:upperCorner>336662.54 4555466.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757101CF3565F_PI.326</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757101CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757101CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757101CF3565F_PI.326" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336661.99 4555466.58 336662.54 4555463.65 336654.87 4555462.2 336654.32 4555465.13 336661.99 4555466.58</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757102CF3565F_PI.327">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336645.74 4555441.3</gml:lowerCorner>
         <gml:upperCorner>336651.03 4555450.07</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757102CF3565F_PI.327</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757102CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757102CF3565F_PI.327" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336647.14 4555441.3 336645.74 4555449.17 336650.82 4555450.07 336651.03 4555448.89 336649.65 4555448.65 336650.85 4555441.96 336647.14 4555441.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757106CF3565F_PI.328">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336601.4 4555429.54</gml:lowerCorner>
         <gml:upperCorner>336607.07 4555439.08</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757106CF3565F_PI.328</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757106CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757106CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757106CF3565F_PI.328" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336601.4 4555438.44 336605.77 4555439.08 336607.07 4555430.17 336602.7 4555429.54 336601.4 4555438.44</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757108CF3565F_PI.329">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336581.95 4555428.52</gml:lowerCorner>
         <gml:upperCorner>336585.36 4555436.62</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757108CF3565F_PI.329</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757108CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757108CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757108CF3565F_PI.329" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336585.36 4555428.62 336582.21 4555428.52 336581.95 4555436.52 336585.1 4555436.62 336585.36 4555428.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757110CF3565F_PI.330">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336592.13 4555446.5</gml:lowerCorner>
         <gml:upperCorner>336599.01 4555453.43</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-11-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757110CF3565F_PI.330</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757110CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757110CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757110CF3565F_PI.330" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10"> 336599.01 4555446.87 336595.17 4555446.5 336595.39 4555447.11 336595.4 4555448.56 336594.77 4555449.89 336593.64 4555450.82 336592.29 4555451.15 336592.13 4555452.82 336598.37 4555453.43 336599.01 4555446.87</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6757113CF3565F_PI.331">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336638.34 4555452.84</gml:lowerCorner>
         <gml:upperCorner>336646.12 4555458.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6757113CF3565F_PI.331</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6757113CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6757113CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6757113CF3565F_PI.331" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="51"> 336645.9 4555457.53 336646.02 4555457.18 336646.1 4555456.51 336646.12 4555456.21 336646.1 4555455.62 336645.96 4555455.03 336645.85 4555454.75 336645.72 4555454.47 336645.36 4555453.96 336644.13 4555453.5 336642.88 4555453.17 336641.6 4555452.95 336640.96 4555452.88 336640.31 4555452.85 336639.65 4555452.84 336639.33 4555452.98 336638.92 4555453.29 336638.6 4555453.7 336638.41 4555454.17 336638.37 4555454.34 336638.34 4555454.68 336638.41 4555455.19 336638.61 4555455.66 336638.81 4555455.93 336639.19 4555456.28 336639.49 4555456.45 336639.98 4555456.6 336640.49 4555456.61 336640.87 4555456.54 336641.08 4555456.14 336641.29 4555455.95 336641.64 4555455.78 336641.92 4555455.73 336642.12 4555455.75 336642.39 4555455.82 336642.57 4555455.91 336642.78 4555456.1 336642.9 4555456.26 336643.02 4555456.52 336643.1 4555457.16 336643.22 4555457.53 336643.42 4555457.84 336643.61 4555458.03 336643.94 4555458.23 336644.17 4555458.32 336644.43 4555458.36 336644.94 4555458.32 336645.29 4555458.18 336645.5 4555458.03 336645.69 4555457.84 336645.9 4555457.53</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764105CF3566D_PI.332">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336475.83 4556096.38</gml:lowerCorner>
         <gml:upperCorner>336483.45 4556104.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-12-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764105CF3566D_PI.332</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764105CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764105CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764105CF3566D_PI.332" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336483.45 4556098.68 336481.03 4556096.38 336475.83 4556101.85 336478.25 4556104.15 336483.45 4556098.68</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764303CF3566D_PI.333">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336644.4895 4556205.986</gml:lowerCorner>
         <gml:upperCorner>336650.5925 4556212.7805</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-06-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764303CF3566D_PI.333</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764303CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764303CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764303CF3566D_PI.333" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336644.4895 4556210.8935 336647.3175 4556212.7805 336650.5925 4556207.873 336647.7645 4556205.986 336644.4895 4556210.8935</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764303CF3566D_PI.334">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336647.065 4556213.8365</gml:lowerCorner>
         <gml:upperCorner>336652.4735 4556218.969</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-06-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764303CF3566D_PI.334</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764303CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764303CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764303CF3566D_PI.334" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336650.641 4556218.969 336652.4735 4556216.2245 336648.898 4556213.8365 336647.065 4556216.5805 336650.641 4556218.969</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764304CF3566D_PI.335">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336597.445 4556222.4045</gml:lowerCorner>
         <gml:upperCorner>336602.575 4556227.6445</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764304CF3566D_PI.335</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764304CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764304CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764304CF3566D_PI.335" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 336598.875 4556222.4045 336597.445 4556224.4645 336600.325 4556226.4545 336600.025 4556226.8945 336599.955 4556227.1445 336599.975 4556227.2745 336600.105 4556227.5045 336600.205 4556227.5745 336600.455 4556227.6445 336600.585 4556227.6245 336600.705 4556227.5745 336600.865 4556227.4345 336602.575 4556224.9645 336598.875 4556222.4045</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764306CF3566D_PI.336">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336612.505 4556232.1945</gml:lowerCorner>
         <gml:upperCorner>336618.745 4556239.1345</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2008-03-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764306CF3566D_PI.336</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764306CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764306CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764306CF3566D_PI.336" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336615.835 4556232.1945 336612.505 4556237.1845 336615.415 4556239.1345 336618.745 4556234.1445 336615.835 4556232.1945</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764307CF3566D_PI.337">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336620.525 4556230.5845</gml:lowerCorner>
         <gml:upperCorner>336625.975 4556237.0645</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2011-11-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764307CF3566D_PI.337</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764307CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764307CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764307CF3566D_PI.337" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 336623.945 4556230.5845 336620.645 4556235.2045 336620.565 4556235.4145 336620.525 4556235.7545 336620.545 4556235.9845 336620.605 4556236.2045 336620.835 4556236.5945 336621.085 4556236.8245 336621.385 4556236.9845 336621.825 4556237.0645 336622.165 4556237.0245 336622.375 4556236.9545 336622.575 4556236.8445 336622.835 4556236.6145 336625.975 4556232.0445 336623.945 4556230.5845</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6764309CF3566D_PI.338">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336600.365 4556229.3445</gml:lowerCorner>
         <gml:upperCorner>336605.675 4556235.1645</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2010-06-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6764309CF3566D_PI.338</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6764309CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6764309CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6764309CF3566D_PI.338" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336603.205 4556229.3445 336600.365 4556233.4545 336602.825 4556235.1645 336605.675 4556231.0545 336603.205 4556229.3445</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767101CF3566F_PI.339">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336632.004726781 4556487.22874252</gml:lowerCorner>
         <gml:upperCorner>336637.535726781 4556491.87724252</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767101CF3566F_PI.339</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767101CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767101CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767101CF3566F_PI.339" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29"> 336637.474726781 4556491.29724252 336637.535726781 4556490.86724252 336637.397226781 4556490.45574252 336637.094726781 4556489.83124252 336636.534226781 4556489.07674252 336635.693226781 4556488.30074252 336634.795226781 4556487.60624252 336634.279226781 4556487.32274252 336633.698726781 4556487.22874252 336633.120226781 4556487.33474252 336632.610226781 4556487.62824252 336632.228726781 4556488.07574252 336632.018726781 4556488.62524252 336632.004726781 4556489.21324252 336632.054226781 4556489.43924252 336632.311226781 4556489.96824252 336632.730726781 4556490.38074252 336633.263726781 4556490.62924252 336633.849726781 4556490.68424252 336634.470226781 4556490.50624252 336634.852726781 4556490.47824252 336635.326726781 4556490.65074252 336635.675726781 4556491.14574252 336635.859726781 4556491.53874252 336636.200226781 4556491.80774252 336636.413226781 4556491.87724252 336636.846726781 4556491.86174252 336637.227726781 4556491.65374252 336637.474726781 4556491.29724252</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767107CF3566F_PI.340">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336557.4955 4556467.4745</gml:lowerCorner>
         <gml:upperCorner>336561.7535 4556472.1915</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-06-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767107CF3566F_PI.340</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767107CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767107CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767107CF3566F_PI.340" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336559.6035 4556472.1915 336561.7535 4556468.8185 336559.646 4556467.4745 336557.4955 4556470.8475 336559.6035 4556472.1915</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767111CF3566F_PI.341">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336596.766226781 4556583.64174252</gml:lowerCorner>
         <gml:upperCorner>336603.375226781 4556589.34824252</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767111CF3566F_PI.341</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767111CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767111CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767111CF3566F_PI.341" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26"> 336603.149726781 4556587.92974252 336603.375226781 4556587.09174252 336603.246226781 4556586.09224252 336602.666226781 4556585.44724252 336601.698726781 4556585.54374252 336601.053726781 4556585.76974252 336600.312226781 4556585.70524252 336599.957726781 4556585.15724252 336599.732226781 4556584.41574252 336599.409726781 4556584.06074252 336599.022726781 4556583.77074251 336598.506726781 4556583.64174252 336597.829726781 4556583.67424252 336597.383226781 4556583.98024252 336596.927226781 4556584.51224252 336596.766226781 4556585.35074252 336596.798226781 4556586.15674252 336597.088226781 4556587.09174252 336597.410726781 4556587.92974252 336598.055726781 4556588.63924252 336598.990726781 4556589.15474252 336599.796726781 4556589.34824252 336600.860726781 4556589.31624252 336601.859726781 4556589.15474252 336602.537226781 4556588.70374252 336603.149726781 4556587.92974252</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767118CF3566F_PI.342">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336608.176 4556520.185</gml:lowerCorner>
         <gml:upperCorner>336615.3865 4556526.8055</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-09-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767118CF3566F_PI.342</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767118CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767118CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767118CF3566F_PI.342" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336610.352 4556520.185 336608.176 4556523.5415 336613.2105 4556526.8055 336615.3865 4556523.449 336610.352 4556520.185</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767119CF3566F_PI.343">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336615.449726781 4556516.86224252</gml:lowerCorner>
         <gml:upperCorner>336620.696726781 4556521.53424252</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767119CF3566F_PI.343</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767119CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767119CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767119CF3566F_PI.343" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 336616.861726781 4556516.86224252 336615.449726781 4556518.77474252 336618.711726781 4556521.29974252 336619.160726781 4556521.51424252 336619.658226781 4556521.53424252 336620.123226781 4556521.35674252 336620.480726781 4556521.01074252 336620.605726781 4556520.77824252 336620.696726781 4556520.28874252 336620.587226781 4556519.80324251 336620.295726781 4556519.39974252 336616.861726781 4556516.86224252</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767122CF3566F_PI.344">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336621.736726781 4556496.84124252</gml:lowerCorner>
         <gml:upperCorner>336626.786726781 4556502.39124252</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767122CF3566F_PI.344</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767122CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767122CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767122CF3566F_PI.344" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336621.736726781 4556500.77124252 336624.226726781 4556502.39124252 336626.786726781 4556498.46124252 336624.296726781 4556496.84124252 336621.736726781 4556500.77124252</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767123CF3566F_PI.345">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336626.336726781 4556491.74124251</gml:lowerCorner>
         <gml:upperCorner>336631.736726781 4556496.29124251</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767123CF3566F_PI.345</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767123CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767123CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767123CF3566F_PI.345" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336630.876726781 4556496.22124252 336631.736726781 4556494.90124252 336631.316726781 4556494.63124252 336631.526726781 4556494.29124251 336627.586726781 4556491.74124251 336626.336726781 4556493.67124252 336630.236726781 4556496.29124251 336630.456726781 4556495.95124251 336630.876726781 4556496.22124252</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6767136CF3566F_PI.346">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336530.709 4556437.1305</gml:lowerCorner>
         <gml:upperCorner>336537.0325 4556442.722</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-01-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6767136CF3566F_PI.346</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6767136CF3566F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6767136CF3566F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6767136CF3566F_PI.346" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336537.0325 4556440.169 336532.378 4556437.1305 336530.709 4556439.687 336535.366 4556442.722 336537.0325 4556440.169</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6856802CF3565F_PI.347">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336766.302 4555399.2615</gml:lowerCorner>
         <gml:upperCorner>336773.365 4555403.8765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-07-31T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6856802CF3565F_PI.347</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6856802CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6856802CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6856802CF3565F_PI.347" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336766.302 4555402.154 336772.57 4555403.8765 336773.365 4555400.984 336767.097 4555399.2615 336766.302 4555402.154</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6856807CF3565F_PI.348">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336701.45 4555392.506</gml:lowerCorner>
         <gml:upperCorner>336710.278 4555397.7945</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6856807CF3565F_PI.348</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6856807CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6856807CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6856807CF3565F_PI.348" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336701.45 4555395.3815 336709.3915 4555397.7945 336710.278 4555394.876 336702.3055 4555392.506 336701.45 4555395.3815</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6857111CF3565F_PI.349">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336720.124 4555510.4035</gml:lowerCorner>
         <gml:upperCorner>336727.3025 4555515.7435</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-04-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6857111CF3565F_PI.349</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6857111CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6857111CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6857111CF3565F_PI.349" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336721.157 4555510.4035 336720.124 4555513.956 336726.269 4555515.7435 336727.3025 4555512.191 336721.157 4555510.4035</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6857113CF3565F_PI.350">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336749.9855 4555453.6415</gml:lowerCorner>
         <gml:upperCorner>336760.9835 4555461.234</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-02-04T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6857113CF3565F_PI.350</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6857113CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6857113CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6857113CF3565F_PI.350" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336751.381 4555453.6415 336749.9855 4555458.443 336759.5885 4555461.234 336760.9835 4555456.4325 336751.381 4555453.6415</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6857702CF3565F_PI.351">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336796.6855 4555532.242</gml:lowerCorner>
         <gml:upperCorner>336801.0205 4555538.0735</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-06-05T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6857702CF3565F_PI.351</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6857702CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6857702CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6857702CF3565F_PI.351" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336796.6855 4555537.2345 336799.566 4555538.0735 336801.0205 4555533.081 336798.14 4555532.242 336796.6855 4555537.2345</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6857706CF3565F_PI.352">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336815.9565 4555469.386</gml:lowerCorner>
         <gml:upperCorner>336820.8505 4555476.118</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-04-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6857706CF3565F_PI.352</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6857706CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6857706CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6857706CF3565F_PI.352" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336819.1645 4555476.118 336820.8505 4555470.319 336817.6425 4555469.386 336815.9565 4555475.1855 336819.1645 4555476.118</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6860181CF3566B_PI.353">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336792.62 4555898.99</gml:lowerCorner>
         <gml:upperCorner>336800.21 4555907.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6860181CF3566B_PI.353</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6860181CF3566B&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6860181CF3566B&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6860181CF3566B_PI.353" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="61"> 336794.06 4555899.44 336793.62 4555899.79 336793.25 4555900.21 336792.96 4555900.68 336792.75 4555901.2 336792.64 4555901.75 336792.62 4555902.03 336792.63 4555902.91 336792.66 4555903.07 336792.8 4555903.37 336793.04 4555903.6 336793.19 4555903.68 336793.5 4555903.76 336793.83 4555903.72 336793.99 4555903.66 336794.13 4555903.58 336794.35 4555903.34 336794.74 4555903.76 336795.05 4555903.97 336795.4 4555904.13 336795.97 4555904.24 336796.35 4555904.22 336796.72 4555904.15 336797.08 4555904 336797.4 4555903.8 336797.23 4555904.27 336796.99 4555904.7 336796.68 4555905.08 336796.5 4555905.25 336796.46 4555905.51 336796.47 4555905.78 336796.52 4555906.04 336796.62 4555906.29 336796.76 4555906.52 336796.94 4555906.72 336797.26 4555906.95 336797.51 4555907.06 336797.77 4555907.12 336798.17 4555907.12 336798.56 4555907.03 336798.8 4555906.91 336799.11 4555906.65 336799.4 4555906.21 336799.74 4555905.13 336799.99 4555904.03 336800.15 4555902.91 336800.21 4555901.78 336800.13 4555901.3 336799.93 4555900.85 336799.74 4555900.59 336799.3 4555900.24 336798.83 4555899.93 336798.34 4555899.67 336797.82 4555899.44 336797.29 4555899.26 336796.75 4555899.12 336796.19 4555899.03 336795.63 4555898.99 336795.07 4555899 336794.55 4555899.17 336794.06 4555899.44</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6865704CF3566D_PI.354">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336759.097 4556250.2315</gml:lowerCorner>
         <gml:upperCorner>336765.318 4556257.308</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-10-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6865704CF3566D_PI.354</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6865704CF3566D&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6865704CF3566D&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6865704CF3566D_PI.354" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336762.5625 4556250.2315 336759.097 4556255.4925 336761.853 4556257.308 336765.318 4556252.0465 336762.5625 4556250.2315</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6956802CF3565F_PI.355">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336701.14 4555312.2</gml:lowerCorner>
         <gml:upperCorner>336706.15 4555318.96</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-11-25T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6956802CF3565F_PI.355</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6956802CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6956802CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6956802CF3565F_PI.355" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336701.14 4555317.86 336703.62 4555318.96 336706.15 4555313.3 336703.67 4555312.2 336701.14 4555317.86</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6957902CF3565F_PI.356">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336864.8525 4555550.714</gml:lowerCorner>
         <gml:upperCorner>336869.411 4555557.3135</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-04-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6957902CF3565F_PI.356</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6957902CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6957902CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6957902CF3565F_PI.356" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336866.531 4555550.714 336864.8525 4555556.474 336867.7325 4555557.3135 336869.411 4555551.553 336866.531 4555550.714</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6957905CF3565F_PI.357">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336891.074 4555494.646</gml:lowerCorner>
         <gml:upperCorner>336898.3335 4555499.659</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-01-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6957905CF3565F_PI.357</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6957905CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6957905CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6957905CF3565F_PI.357" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336891.074 4555497.8145 336897.411 4555499.659 336898.3335 4555496.4905 336891.9965 4555494.646 336891.074 4555497.8145</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6957911CF3565F_PI.358">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336835.106 4555562.5535</gml:lowerCorner>
         <gml:upperCorner>336843.905 4555568.63</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6957911CF3565F_PI.358</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6957911CF3565F&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6957911CF3565F&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6957911CF3565F_PI.358" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336835.106 4555566.394 336842.787 4555568.63 336843.905 4555564.7895 336836.224 4555562.5535 336835.106 4555566.394</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6960901CF3566B_PI.359">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336836.263 4555903.6525</gml:lowerCorner>
         <gml:upperCorner>336843.293 4555917.5125</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6960901CF3566B_PI.359</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6960901CF3566B&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6960901CF3566B&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6960901CF3566B_PI.359" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336843.293 4555917.4725 336843.223 4555903.6525 336836.263 4555903.6925 336836.333 4555917.5125 336843.293 4555917.4725</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6963608CF3576C_PI.360">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336911.84 4556114.12</gml:lowerCorner>
         <gml:upperCorner>336921.65 4556124.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6963608CF3576C_PI.360</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6963608CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6963608CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6963608CF3576C_PI.360" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336921.65 4556117.18 336917.95 4556114.12 336911.84 4556121.5 336915.54 4556124.56 336921.65 4556117.18</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6963610CF3576C_PI.361">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336878.46 4556116.3</gml:lowerCorner>
         <gml:upperCorner>336884.56 4556123.48</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6963610CF3576C_PI.361</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6963610CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6963610CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6963610CF3576C_PI.361" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336880.74 4556123.48 336884.56 4556117.85 336882.28 4556116.3 336878.46 4556121.93 336880.74 4556123.48</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6964902CF3576C_PI.362">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336823.1995 4556224.5215</gml:lowerCorner>
         <gml:upperCorner>336831.8025 4556232.2405</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-12-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6964902CF3576C_PI.362</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6964902CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6964902CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6964902CF3576C_PI.362" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336829.4075 4556232.2405 336831.8025 4556228.549 336825.594 4556224.5215 336823.1995 4556228.213 336829.4075 4556232.2405</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6964919CF3576C_PI.363">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336741.07 4556185.81</gml:lowerCorner>
         <gml:upperCorner>336745.4 4556190.52</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6964919CF3576C_PI.363</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6964919CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6964919CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6964919CF3576C_PI.363" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336741.07 4556189.1 336743.13 4556190.52 336745.4 4556187.22 336743.34 4556185.81 336741.07 4556189.1</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7059604CF3566B_PI.364">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336863.9375 4555837.1435</gml:lowerCorner>
         <gml:upperCorner>336870.7725 4555840.7195</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7059604CF3566B_PI.364</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7059604CF3566B&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7059604CF3566B&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7059604CF3566B_PI.364" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336863.951 4555840.7195 336870.7725 4555840.694 336870.759 4555837.1435 336863.9375 4555837.1695 336863.951 4555840.7195</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7060733CF3576A_PI.365">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336944.6235 4555916.9815</gml:lowerCorner>
         <gml:upperCorner>336947.6235 4555919.5015</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7060733CF3576A_PI.365</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7060733CF3576A&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7060733CF3576A&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7060733CF3576A_PI.365" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="91"> 336947.2135 4555919.5015 336947.2735 4555919.4515 336947.3235 4555919.3915 336947.3635 4555919.3315 336947.4035 4555919.2715 336947.4435 4555919.2015 336947.4735 4555919.1415 336947.5035 4555919.0715 336947.5335 4555919.0015 336947.5535 4555918.9315 336947.5735 4555918.8615 336947.5935 4555918.7915 336947.6035 4555918.7215 336947.6135 4555918.6415 336947.6235 4555918.5715 336947.6235 4555918.5015 336947.6235 4555918.4215 336947.6235 4555918.3515 336947.6135 4555918.2815 336947.6035 4555918.2015 336947.5835 4555918.1315 336947.5635 4555918.0615 336947.5435 4555917.9915 336947.5135 4555917.9215 336947.4835 4555917.8515 336947.4535 4555917.7915 336947.4235 4555917.7215 336947.3835 4555917.6615 336947.3335 4555917.6015 336947.2935 4555917.5415 336947.2435 4555917.4815 336947.1935 4555917.4315 336947.1435 4555917.3815 336947.0835 4555917.3315 336947.0335 4555917.2815 336946.9735 4555917.2415 336946.9035 4555917.2015 336946.8435 4555917.1615 336946.7735 4555917.1315 336946.7135 4555917.1015 336946.6435 4555917.0715 336946.5735 4555917.0515 336946.5035 4555917.0315 336946.4335 4555917.0115 336946.3535 4555917.0015 336946.2835 4555916.9915 336946.2135 4555916.9815 336946.1335 4555916.9815 336946.0635 4555916.9815 336945.9935 4555916.9915 336945.9135 4555917.0015 336945.8435 4555917.0115 336945.7735 4555917.0215 336945.7035 4555917.0415 336945.6335 4555917.0615 336945.5635 4555917.0915 336945.4935 4555917.1215 336945.4235 4555917.1515 336945.3635 4555917.1915 336945.3035 4555917.2315 336945.2435 4555917.2715 336945.1835 4555917.3115 336945.1235 4555917.3615 336945.0735 4555917.4115 336945.0235 4555917.4715 336944.9735 4555917.5215 336944.9235 4555917.5815 336944.8835 4555917.6415 336944.8435 4555917.7015 336944.8035 4555917.7615 336944.7735 4555917.8315 336944.7435 4555917.9015 336944.7135 4555917.9715 336944.6935 4555918.0415 336944.6735 4555918.1115 336944.6535 4555918.1815 336944.6435 4555918.2515 336944.6335 4555918.3215 336944.6235 4555918.4015 336944.6235 4555918.4715 336944.6235 4555918.5415 336944.6235 4555918.6215 336944.6335 4555918.6915 336944.6435 4555918.7615 336944.6635 4555918.8415 336944.6835 4555918.9115 336944.7035 4555918.9815 336944.7335 4555919.0515 336944.7635 4555919.1315 336947.1735 4555918.9415 336947.2135 4555919.5015</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7161105CF6576A_PI.366">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337040.364 4555894.417</gml:lowerCorner>
         <gml:upperCorner>337048.8535 4555899.096</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-10-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7161105CF6576A_PI.366</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7161105CF6576A&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7161105CF6576A&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7161105CF6576A_PI.366" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337040.5625 4555899.096 337048.8535 4555898.7125 337048.655 4555894.417 337040.364 4555894.8005 337040.5625 4555899.096</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7260916CF3576A_PI.367">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337114.8735 4555892.17</gml:lowerCorner>
         <gml:upperCorner>337120.6835 4555897.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7260916CF3576A_PI.367</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7260916CF3576A&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7260916CF3576A&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7260916CF3576A_PI.367" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="129"> 337118.4835 4555892.25 337118.3435 4555892.22 337118.2035 4555892.2 337118.0635 4555892.18 337117.9235 4555892.17 337117.7835 4555892.17 337117.6335 4555892.17 337117.4935 4555892.18 337117.3535 4555892.2 337117.2135 4555892.22 337117.0735 4555892.25 337116.9335 4555892.29 337116.8035 4555892.34 337116.6635 4555892.39 337116.5335 4555892.45 337116.4035 4555892.51 337116.2835 4555892.58 337116.1635 4555892.66 337116.0435 4555892.74 337115.9335 4555892.83 337115.8235 4555892.92 337115.7235 4555893.02 337115.6235 4555893.12 337115.5335 4555893.23 337115.4435 4555893.34 337115.3635 4555893.46 337115.2835 4555893.58 337115.2135 4555893.7 337115.1535 4555893.83 337115.0935 4555893.96 337115.0435 4555894.1 337114.9935 4555894.23 337114.9535 4555894.37 337114.9235 4555894.51 337114.9035 4555894.65 337114.8835 4555894.79 337114.8735 4555894.93 337114.8735 4555895.08 337114.8735 4555895.22 337114.8835 4555895.36 337114.9035 4555895.5 337114.9235 4555895.64 337114.9535 4555895.78 337114.9935 4555895.92 337115.0435 4555896.05 337115.0935 4555896.19 337115.1535 4555896.32 337115.2135 4555896.45 337115.2835 4555896.57 337115.3635 4555896.69 337115.4435 4555896.81 337115.5335 4555896.92 337115.6235 4555897.03 337115.7235 4555897.13 337115.8235 4555897.23 337115.9335 4555897.32 337116.0435 4555897.41 337116.1635 4555897.49 337116.2835 4555897.57 337116.4035 4555897.64 337116.5335 4555897.7 337116.6635 4555897.76 337116.8035 4555897.81 337116.9335 4555897.86 337117.0735 4555897.9 337117.2135 4555897.93 337117.3535 4555897.95 337117.4935 4555897.97 337117.6335 4555897.98 337117.7835 4555897.98 337117.9235 4555897.98 337118.0635 4555897.97 337118.2035 4555897.95 337118.3435 4555897.93 337118.4835 4555897.9 337118.6235 4555897.86 337118.7535 4555897.81 337118.8935 4555897.76 337119.0235 4555897.7 337119.1535 4555897.64 337119.2735 4555897.57 337119.3935 4555897.49 337119.5135 4555897.41 337119.6235 4555897.32 337119.7335 4555897.23 337119.8335 4555897.13 337119.9335 4555897.03 337120.0235 4555896.92 337120.1135 4555896.81 337120.1935 4555896.69 337120.2735 4555896.57 337120.3435 4555896.45 337120.4035 4555896.32 337120.4635 4555896.19 337120.5135 4555896.05 337120.5635 4555895.92 337120.6035 4555895.78 337120.6335 4555895.64 337120.6535 4555895.5 337120.6735 4555895.36 337120.6835 4555895.22 337120.6835 4555895.08 337120.6835 4555894.93 337120.6735 4555894.79 337120.6535 4555894.65 337120.6335 4555894.51 337120.6035 4555894.37 337120.5635 4555894.23 337120.5135 4555894.1 337120.4635 4555893.96 337120.4035 4555893.83 337120.3435 4555893.7 337120.2735 4555893.58 337120.1935 4555893.46 337120.1135 4555893.34 337120.0235 4555893.23 337119.9335 4555893.12 337119.8335 4555893.02 337119.7335 4555892.92 337119.6235 4555892.83 337119.5135 4555892.74 337119.3935 4555892.66 337119.2735 4555892.58 337119.1535 4555892.51 337119.0235 4555892.45 337118.8935 4555892.39 337118.7535 4555892.34 337118.6235 4555892.29 337118.4835 4555892.25</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263112CF3576C_PI.368">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337141.194 4555996.06</gml:lowerCorner>
         <gml:upperCorner>337147.824 4556003.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263112CF3576C_PI.368</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263112CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263112CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263112CF3576C_PI.368" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337144.9645 4556003.98 337147.824 4555998.58 337144.994 4555996.06 337141.194 4556000.25 337144.9645 4556003.98</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263136CF3576C_PI.369">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336869.26 4556027.19</gml:lowerCorner>
         <gml:upperCorner>336873.65 4556032.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263136CF3576C_PI.369</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263136CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263136CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263136CF3576C_PI.369" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336871.44 4556032.75 336871.95 4556032.01 336871.37 4556031.62 336873.65 4556028.28 336872.05 4556027.19 336869.26 4556031.27 336871.44 4556032.75</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263137CF3576C_PI.370">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336876.12 4556027.32</gml:lowerCorner>
         <gml:upperCorner>336882 4556032.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263137CF3576C_PI.370</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263137CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263137CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263137CF3576C_PI.370" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 336876.12 4556030.84 336878.97 4556032.78 336882 4556028.3 336880.54 4556027.32 336879.73 4556028.52 336877.46 4556028.86 336876.12 4556030.84</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263140CF3576C_PI.371">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336892.452 4556040.727</gml:lowerCorner>
         <gml:upperCorner>336899.156 4556048.071</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-04-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263140CF3576C_PI.371</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263140CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263140CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263140CF3576C_PI.371" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336896.027 4556040.727 336892.452 4556045.9145 336895.581 4556048.071 336899.156 4556042.8835 336896.027 4556040.727</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263151CF3576C_PI.372">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336958.6435 4556071.153</gml:lowerCorner>
         <gml:upperCorner>336962.7955 4556076.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-05-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263151CF3576C_PI.372</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263151CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263151CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263151CF3576C_PI.372" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336960.8895 4556071.153 336958.6435 4556072.252 336960.5245 4556076.34 336962.7955 4556075.295 336960.8895 4556071.153</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263152CF3576C_PI.373">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336974.22 4556068.83</gml:lowerCorner>
         <gml:upperCorner>336984.55 4556071.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263152CF3576C_PI.373</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263152CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263152CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263152CF3576C_PI.373" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 336984.55 4556071.55 336984.51 4556068.83 336975.06 4556068.93 336974.22 4556069.5 336975.12 4556071.01 336976.49 4556070.07 336976.91 4556070.07 336977.79 4556071.87 336984.55 4556071.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263165CF3576C_PI.374">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337015.12 4556053.53</gml:lowerCorner>
         <gml:upperCorner>337023.77 4556060.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263165CF3576C_PI.374</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263165CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263165CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263165CF3576C_PI.374" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 337016.54 4556060.91 337018.28 4556060.44 337017.78 4556058.59 337023.77 4556056.99 337022.85 4556053.53 337015.12 4556055.59 337016.54 4556060.91</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263178CF3576C_PI.375">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336931.98 4556033.84</gml:lowerCorner>
         <gml:upperCorner>336944.72 4556043.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-02-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263178CF3576C_PI.375</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263178CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263178CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263178CF3576C_PI.375" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336944.72 4556043.88 336943.4 4556035.08 336933.01 4556033.84 336931.98 4556042.48 336944.72 4556043.88</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7263178CF3576C_PI.376">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>336937.41 4556047.13</gml:lowerCorner>
         <gml:upperCorner>336945.25 4556051.11</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-02-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7263178CF3576C_PI.376</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7263178CF3576C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7263178CF3576C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7263178CF3576C_PI.376" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 336945.25 4556051.11 336944.82 4556047.79 336937.71 4556047.13 336937.41 4556050.39 336945.25 4556051.11</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7456901CF3575E_PI.377">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337322.5505 4555493.208</gml:lowerCorner>
         <gml:upperCorner>337326.7105 4555497.618</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7456901CF3575E_PI.377</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7456901CF3575E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7456901CF3575E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7456901CF3575E_PI.377" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="121"> 337325.7705 4555497.268 337325.8605 4555497.208 337325.9405 4555497.148 337326.0205 4555497.078 337326.0905 4555497.008 337326.1605 4555496.938 337326.2305 4555496.858 337326.2905 4555496.778 337326.3505 4555496.698 337326.4105 4555496.618 337326.4605 4555496.528 337326.5005 4555496.438 337326.5405 4555496.338 337326.5805 4555496.248 337326.6105 4555496.148 337326.6405 4555496.048 337326.6605 4555495.948 337326.6805 4555495.848 337326.7005 4555495.748 337326.7005 4555495.648 337326.7105 4555495.548 337326.7005 4555495.448 337326.7005 4555495.338 337326.6905 4555495.238 337326.6705 4555495.138 337326.6505 4555495.038 337326.6205 4555494.948 337326.5905 4555494.848 337326.5505 4555494.748 337326.5105 4555494.658 337326.4705 4555494.568 337326.4205 4555494.478 337326.3605 4555494.388 337326.3005 4555494.308 337326.2405 4555494.228 337326.1805 4555494.148 337326.1105 4555494.078 337326.0305 4555494.008 337325.9605 4555493.938 337325.8805 4555493.878 337325.9705 4555493.608 337324.9905 4555493.208 337324.7805 4555493.468 337324.7405 4555493.458 337324.6405 4555493.458 337324.5405 4555493.458 337324.4405 4555493.468 337324.3405 4555493.478 337324.2305 4555493.498 337324.1305 4555493.518 337324.0405 4555493.548 337323.9405 4555493.578 337323.8405 4555493.608 337323.7505 4555493.648 337323.6605 4555493.698 337323.5705 4555493.748 337323.4805 4555493.798 337323.4005 4555493.858 337323.3205 4555493.918 337323.2405 4555493.988 337323.1705 4555494.058 337323.1005 4555494.128 337323.0305 4555494.208 337322.9705 4555494.288 337322.9105 4555494.368 337322.8505 4555494.458 337322.8005 4555494.548 337322.7605 4555494.638 337322.7105 4555494.728 337322.6805 4555494.828 337322.6405 4555494.918 337322.6205 4555495.018 337322.5905 4555495.118 337322.5805 4555495.218 337322.5605 4555495.318 337322.5505 4555495.418 337322.5505 4555495.528 337322.5505 4555495.628 337322.5605 4555495.728 337322.5705 4555495.828 337322.5905 4555495.928 337322.6105 4555496.028 337322.6405 4555496.128 337322.6705 4555496.228 337322.7105 4555496.318 337322.7505 4555496.418 337322.7905 4555496.508 337322.8405 4555496.598 337322.9005 4555496.678 337322.9505 4555496.768 337323.0205 4555496.848 337323.0805 4555496.918 337323.1505 4555496.998 337323.2305 4555497.068 337323.3005 4555497.138 337323.3805 4555497.198 337323.4705 4555497.258 337323.5505 4555497.308 337323.6405 4555497.358 337323.7305 4555497.408 337323.8205 4555497.448 337323.9205 4555497.488 337324.0205 4555497.518 337324.1105 4555497.548 337324.2105 4555497.568 337324.3105 4555497.588 337324.4105 4555497.598 337324.5205 4555497.608 337324.6205 4555497.618 337324.7205 4555497.608 337324.8205 4555497.608 337324.9205 4555497.588 337325.0205 4555497.578 337325.1205 4555497.558 337325.2205 4555497.528 337325.3205 4555497.498 337325.4105 4555497.458 337325.5105 4555497.418 337325.6005 4555497.378 337325.6905 4555497.328 337325.7705 4555497.268</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7456901CF3575E_PI.378">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337323.9605 4555481.148</gml:lowerCorner>
         <gml:upperCorner>337334.7205 4555494.568</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7456901CF3575E_PI.378</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7456901CF3575E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7456901CF3575E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7456901CF3575E_PI.378" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 337334.7205 4555483.848 337329.3505 4555481.148 337323.9605 4555491.868 337329.3305 4555494.568 337334.7205 4555483.848</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7456906CF3575E_PI.379">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337357.3705 4555437.6575</gml:lowerCorner>
         <gml:upperCorner>337365.4505 4555447.1775</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-06-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7456906CF3575E_PI.379</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7456906CF3575E&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7456906CF3575E&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7456906CF3575E_PI.379" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 337365.4505 4555440.9675 337361.7805 4555437.6575 337357.3705 4555442.2575 337357.4505 4555442.4375 337357.5205 4555442.6175 337357.5805 4555442.7975 337357.6305 4555442.9775 337357.6805 4555443.1675 337357.7205 4555443.3575 337357.7405 4555443.5475 337357.7605 4555443.7375 337357.7705 4555443.9275 337357.7705 4555444.1275 337357.7505 4555444.3175 337357.7305 4555444.5075 337357.7005 4555444.6975 337357.6605 4555444.8875 337357.6205 4555445.0775 337357.5405 4555445.3275 337359.4605 4555447.1775 337365.4505 4555440.9675</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.7550102CF3575B_PI.380">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>337497.61 4554878.84</gml:lowerCorner>
         <gml:upperCorner>337507.62 4554887.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-01-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>7550102CF3575B_PI.380</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=7550102CF3575B&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=7550102CF3575B&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.7550102CF3575B_PI.380" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 337505.06 4554887.66 337507.62 4554884.2 337500.39 4554878.84 337500 4554879.37 337499.62 4554879.16 337499.37 4554879.09 337499.11 4554879.07 337498.85 4554879.09 337498.6 4554879.16 337498.36 4554879.27 337498.14 4554879.42 337497.81 4554879.82 337497.66 4554880.18 337497.61 4554880.44 337497.63 4554880.83 337497.75 4554881.2 337497.96 4554881.53 337498.22 4554881.78 337497.83 4554882.3 337505.06 4554887.66</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.8464301CF3586C_PI.381">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25831">
         <gml:lowerCorner>338348.25 4556574.7615</gml:lowerCorner>
         <gml:upperCorner>338357.824 4556584.513</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>8464301CF3586C_PI.381</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=8464301CF3586C&amp;srsname=EPSG::25831"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=8464301CF3586C&amp;srsname=EPSG::25831"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.8464301CF3586C_PI.381" srsName="urn:ogc:def:crs:EPSG::25831">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 338351.9115 4556574.8515 338348.25 4556581.6825 338353.53 4556584.513 338357.824 4556577.905 338351.9595 4556574.7615 338351.9115 4556574.8515</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
</gml:FeatureCollection>
